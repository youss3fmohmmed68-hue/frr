import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Modality } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  let ai: GoogleGenAI | null = null;
  function getAI() {
    if (!ai) {
      ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY || "",
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return ai;
  }

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", hasKey: Boolean(process.env.GEMINI_API_KEY) });
  });

  // Chat completion endpoint with auto-fallback and retry for 503/429
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, systemInstruction, userName = "Tanvir" } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: "Messages array is required." });
      }

      const client = getAI();
      const defaultInstruction = `You are a sophisticated, friendly, and helpful AI assistant named Crimson.
The user's name is ${userName}.
You respond intelligently, warmly, and concisely with clear formatting.
If the user asks in Arabic, respond in fluent natural Arabic. If the user asks in English, respond in polished English.
Support code snippets with markdown, bullet points, and clean explanations.`;

      // Build contents for Gemini generateContent
      const contents = messages.map((m: { role: string; content: string }) => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.content }],
      }));

      // Try models in order of preference if one suffers from temporary 503/high demand
      const candidateModels = ["gemini-3.7-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
      let lastError: any = null;
      let responseText: string | null = null;

      for (const model of candidateModels) {
        // Try up to 2 attempts per candidate with backoff if 503 occurs
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            const response = await client.models.generateContent({
              model,
              contents,
              config: {
                systemInstruction: systemInstruction || defaultInstruction,
                temperature: 0.7,
              },
            });

            if (response.text) {
              responseText = response.text;
              break;
            }
          } catch (err: any) {
            lastError = err;
            const isTransient =
              err?.status === "UNAVAILABLE" ||
              err?.code === 503 ||
              err?.message?.includes("503") ||
              err?.message?.includes("high demand") ||
              err?.message?.includes("RESOURCE_EXHAUSTED") ||
              err?.code === 429;

            if (isTransient && attempt === 0) {
              // Wait 600ms before retrying once
              await new Promise((resolve) => setTimeout(resolve, 600));
              continue;
            }
            // Move to next candidate model if transient
            if (isTransient) {
              console.warn(`Model ${model} experienced high demand, trying fallback model...`);
              break;
            }
            // If non-transient, throw or break
            break;
          }
        }

        if (responseText) {
          break;
        }
      }

      if (responseText) {
        return res.json({ text: responseText });
      }

      console.error("All Gemini Chat attempts failed:", lastError);
      return res.status(200).json({
        text: "I am currently experiencing high network demand. Please ask your question again, and I'll be glad to help!"
      });
    } catch (error: any) {
      console.error("Gemini Chat Critical Error:", error);
      res.status(200).json({
        text: "Hello! I am ready to assist you. Could you please rephrase or try again in a moment?"
      });
    }
  });

  // Speech Generation (TTS) endpoint
  app.post("/api/tts", async (req, res) => {
    try {
      const { text, voiceName = "Kore" } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      const client = getAI();
      // Use standard Gemini TTS
      const response = await client.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text: `Say clearly and warmly: ${text.slice(0, 400)}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voiceName || "Kore" },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        return res.json({ audio: base64Audio, format: "pcm", sampleRate: 24000 });
      }
      return res.status(404).json({ error: "No audio generated" });
    } catch (error: any) {
      console.warn("TTS fallback needed:", error?.message);
      // Return flag indicating client-side Web Speech fallback should be used
      res.status(200).json({ fallback: true, error: error?.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
