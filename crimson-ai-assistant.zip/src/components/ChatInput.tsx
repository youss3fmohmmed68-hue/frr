import React, { useState, useRef, useEffect } from "react";
import { ArrowUp, Mic, MicOff, AudioLines, StopCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  onStartVoice: () => void;
  isListening?: boolean;
  disabled?: boolean;
  placeholder?: string;
  className?: string;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onStartVoice,
  isListening = false,
  disabled = false,
  placeholder = "Ask anything...",
  className = "",
}) => {
  const [inputVal, setInputVal] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputVal.trim();
    if (!trimmed || disabled) return;
    onSendMessage(trimmed);
    setInputVal("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div id="chat-input-wrapper" className={`w-full max-w-md mx-auto px-4 ${className}`}>
      {/* Floating crimson glassmorphic pill bar (Faithful replica of image) */}
      <form
        onSubmit={handleSubmit}
        id="chat-input-form"
        className="relative flex items-center justify-between w-full h-[58px] px-5 rounded-full bg-gradient-to-r from-red-950/50 via-[#2d0208]/60 to-red-950/50 backdrop-blur-2xl border border-red-500/25 shadow-[0_8px_32px_rgba(0,0,0,0.6),0_0_20px_rgba(180,10,30,0.2)] focus-within:border-red-500/50 focus-within:shadow-[0_0_25px_rgba(230,20,50,0.35)] transition-all duration-300"
      >
        {/* Text Input */}
        <input
          ref={inputRef}
          id="user-chat-input"
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? "Listening to your voice..." : placeholder}
          disabled={disabled || isListening}
          className="flex-1 bg-transparent text-white placeholder-white/50 text-base font-normal tracking-wide focus:outline-none disabled:opacity-50 pr-3"
          autoComplete="off"
        />

        {/* Right Action Icons: Waveform Mic / Send Button */}
        <div className="flex items-center space-x-2">
          <AnimatePresence mode="wait">
            {inputVal.trim().length > 0 ? (
              <motion.button
                key="send-btn"
                id="btn-send-message"
                type="submit"
                disabled={disabled}
                initial={{ scale: 0.7, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.7, opacity: 0 }}
                className="w-9 h-9 flex items-center justify-center rounded-full bg-gradient-to-r from-red-600 to-rose-500 text-white shadow-lg hover:brightness-110 active:scale-95 transition-all"
                title="Send message"
              >
                <ArrowUp className="w-5 h-5 stroke-[2.5]" />
              </motion.button>
            ) : (
              <motion.button
                key="voice-btn"
                id="btn-voice-trigger"
                type="button"
                onClick={onStartVoice}
                disabled={disabled}
                initial={{ scale: 0.7, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.7, opacity: 0 }}
                className={`p-2 rounded-full transition-all duration-200 active:scale-95 ${
                  isListening
                    ? "text-red-400 bg-red-500/20 animate-pulse ring-2 ring-red-500/40"
                    : "text-white/80 hover:text-white hover:bg-white/10"
                }`}
                title={isListening ? "Stop listening" : "Start voice mode"}
              >
                {isListening ? (
                  <StopCircle className="w-6 h-6 stroke-[2.2]" />
                ) : (
                  <div className="flex items-center space-x-0.5">
                    <span className="w-1 h-3 bg-white/70 rounded-full animate-pulse" />
                    <span className="w-1 h-5 bg-white/90 rounded-full animate-pulse [animation-delay:150ms]" />
                    <span className="w-1 h-3.5 bg-white/70 rounded-full animate-pulse [animation-delay:300ms]" />
                    <span className="w-1 h-2 bg-white/50 rounded-full animate-pulse [animation-delay:450ms]" />
                  </div>
                )}
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </form>
    </div>
  );
};
