import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ChevronLeft,
  ChevronRight,
  Settings as SettingsIcon,
  User,
  Globe,
  Palette,
  Bell,
  ShieldCheck,
  Lock,
  Bot,
  LogOut,
  Info,
  X,
  Check,
  Sliders,
  Volume2,
  Trash2,
  Signal,
  Wifi,
  Battery,
} from "lucide-react";
import { RubyOrb } from "./RubyOrb";
import { UserProfile } from "../types";

interface SettingsViewProps {
  user: UserProfile;
  onBack: () => void;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onLogout: () => void;
  onClearHistory?: () => void;
}

type SubModal =
  | null
  | "account"
  | "language"
  | "appearance"
  | "notifications"
  | "privacy"
  | "password"
  | "assistant"
  | "about";

export const SettingsView: React.FC<SettingsViewProps> = ({
  user,
  onBack,
  onUpdateUser,
  onLogout,
  onClearHistory,
}) => {
  const [activeModal, setActiveModal] = useState<SubModal>(null);

  // Form states for Sub-modals
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email || "tanvir@example.com");
  const [personality, setPersonality] = useState(user.personality);
  const [voiceName, setVoiceName] = useState(user.voiceName);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundEffects, setSoundEffects] = useState(true);
  const [passwordOld, setPasswordOld] = useState("");
  const [passwordNew, setPasswordNew] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const isRTL = user.preferredLanguage === "ar";

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({ name, email });
    setActiveModal(null);
    showToast(isRTL ? "تم تحديث الحساب بنجاح" : "Account updated successfully");
  };

  const handleSaveAssistant = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({ personality, voiceName });
    setActiveModal(null);
    showToast(isRTL ? "تم حفظ إعدادات المساعد" : "Assistant settings updated");
  };

  const handleLanguageSelect = (lang: "en" | "ar") => {
    onUpdateUser({ preferredLanguage: lang });
    setActiveModal(null);
    showToast(lang === "ar" ? "تم تغيير اللغة إلى العربية" : "Language set to English");
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordOld || !passwordNew) return;
    setPasswordSuccess(true);
    setTimeout(() => {
      setPasswordSuccess(false);
      setPasswordOld("");
      setPasswordNew("");
      setActiveModal(null);
      showToast(isRTL ? "تم تغيير كلمة المرور بنجاح" : "Password changed successfully");
    }, 800);
  };

  const settingsItems = [
    {
      id: "account" as const,
      icon: <User className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "الحساب" : "Account",
      subtitle: isRTL ? "الملف الشخصي والبريد الإلكتروني" : "Profile, email & password",
      action: () => setActiveModal("account"),
    },
    {
      id: "language" as const,
      icon: <Globe className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "اللغة" : "Language",
      subtitle:
        user.preferredLanguage === "ar"
          ? isRTL ? "العربية" : "Arabic"
          : isRTL ? "الإنجليزية (US)" : "English (US)",
      action: () => setActiveModal("language"),
    },
    {
      id: "appearance" as const,
      icon: <Palette className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "المظهر" : "Appearance",
      subtitle: isRTL ? "الوضع الليلي القرمزي" : "Dark mode",
      action: () => setActiveModal("appearance"),
    },
    {
      id: "notifications" as const,
      icon: <Bell className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "الإشعارات" : "Notifications",
      subtitle: isRTL ? "إدارة التنبيهات والأصوات" : "Manage your alerts",
      action: () => setActiveModal("notifications"),
    },
    {
      id: "privacy" as const,
      icon: <ShieldCheck className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "الخصوصية والأمان" : "Privacy & Security",
      subtitle: isRTL ? "التحكم في بياناتك وسجل المحادثات" : "Control your data",
      action: () => setActiveModal("privacy"),
    },
    {
      id: "password" as const,
      icon: <Lock className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "كلمة المرور" : "Password",
      subtitle: isRTL ? "تغيير كلمة المرور الخاصة بك" : "Change your password",
      action: () => setActiveModal("password"),
    },
    {
      id: "assistant" as const,
      icon: <Bot className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "إعدادات المساعد" : "Assistant Settings",
      subtitle: isRTL ? "تخصيص شخصية وصوت المساعد الذكي" : "Customize your assistant",
      action: () => setActiveModal("assistant"),
    },
    {
      id: "logout" as const,
      icon: <LogOut className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "تسجيل الخروج" : "Log Out",
      subtitle: isRTL ? "الخروج من حسابك الحالي" : "Sign out from your account",
      action: onLogout,
    },
    {
      id: "about" as const,
      icon: <Info className="w-5 h-5 text-red-500 stroke-[1.8]" />,
      title: isRTL ? "حول التطبيق" : "About App",
      subtitle: "Version 1.0.0",
      action: () => setActiveModal("about"),
    },
  ];

  return (
    <div
      id="settings-screen-container"
      dir={isRTL ? "rtl" : "ltr"}
      className="relative w-full h-full max-h-full flex flex-col justify-between px-3.5 sm:px-4 py-2 sm:py-3 select-none text-white overflow-hidden"
    >
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-3.5 py-1.5 rounded-full bg-red-600/90 text-white text-xs font-medium backdrop-blur-md shadow-xl border border-red-400/40"
          >
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Mobile Status Bar (9:41, Dynamic Island, Battery/Wifi) */}
      <div className="w-full shrink-0 flex items-center justify-between text-[11px] text-white/80 font-medium tracking-tight z-20">
        <span className="font-semibold text-white/90 pl-1">9:41</span>

        {/* Dynamic Island Pill Notch */}
        <div className="w-20 h-3.5 bg-black/90 border border-white/10 rounded-full flex items-center justify-center space-x-1.5 shadow-inner">
          <div className="w-2 h-2 bg-neutral-900 rounded-full border border-neutral-800 flex items-center justify-center">
            <div className="w-0.5 h-0.5 bg-red-500/80 rounded-full animate-pulse" />
          </div>
          <div className="w-1.5 h-1.5 bg-neutral-900 rounded-full" />
        </div>

        {/* Status icons */}
        <div className="flex items-center space-x-1.5 text-white/90 pr-1">
          <Signal className="w-3 h-3 stroke-[2.5]" />
          <Wifi className="w-3 h-3 stroke-[2.5]" />
          <Battery className="w-3.5 h-3.5 stroke-[2.2] fill-white/80" />
        </div>
      </div>

      {/* Back Button Row */}
      <div className="w-full shrink-0 flex items-center justify-start z-20 pt-1 pb-0.5">
        <button
          id="btn-settings-back"
          onClick={onBack}
          aria-label="Back"
          className="w-8 h-8 rounded-full bg-neutral-900/90 hover:bg-neutral-800 border border-red-950/60 hover:border-red-500/50 flex items-center justify-center text-white/90 hover:text-white active:scale-95 transition-all shadow-md"
        >
          <ChevronLeft className={`w-4 h-4 text-white ${isRTL ? "rotate-180" : ""}`} />
        </button>
      </div>

      {/* Center Top Section: Glowing Ruby Orb with Cog + Title & Subtitle */}
      <div className="shrink-0 flex flex-col items-center justify-center text-center my-0 z-10">
        {/* 3D Ruby Orb with Settings Cog Inside (Exact match to screenshot 1:1) */}
        <div className="my-0.5">
          <RubyOrb state="idle" size="compact">
            <SettingsIcon className="w-7 h-7 text-red-500 stroke-[1.8]" />
          </RubyOrb>
        </div>

        {/* Title & Subtitle */}
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-0.5">
          {isRTL ? "الإعدادات" : "Settings"}
        </h1>
        <p className="text-[11px] sm:text-xs text-white/60 font-normal mt-0.5 mb-1.5">
          {isRTL ? "إدارة تفضيلاتك وحسابك" : "Manage your preferences"}
        </p>
      </div>

      {/* Settings Items List (9 exact rounded cards fitting 100% without scroll) */}
      <div className="flex-1 flex flex-col justify-between w-full max-w-md mx-auto space-y-1 sm:space-y-1.5 pb-1 z-10">
        {settingsItems.map((item) => (
          <button
            key={item.id}
            id={`settings-item-${item.id}`}
            onClick={item.action}
            className="w-full flex-1 max-h-[50px] flex items-center justify-between px-3 py-1.5 sm:py-2 rounded-xl sm:rounded-2xl bg-[#120204]/90 hover:bg-[#1a0307] active:bg-[#25040a] border border-white/[0.08] hover:border-red-500/40 transition-all text-left rtl:text-right group shadow-sm"
          >
            <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0 pr-2">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-center shrink-0 group-hover:border-red-500/30 group-hover:shadow-[0_0_10px_rgba(239,68,68,0.25)] transition-all">
                {React.cloneElement(item.icon, { className: "w-4 h-4 text-red-500 stroke-[1.8]" })}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs sm:text-sm font-semibold text-white tracking-tight truncate leading-tight">
                  {item.title}
                </span>
                <span className="text-[10px] sm:text-[11px] text-white/50 font-normal truncate leading-tight">
                  {item.subtitle}
                </span>
              </div>
            </div>

            <ChevronRight
              className={`w-3.5 h-3.5 text-white/40 group-hover:text-white/80 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-all shrink-0 ${
                isRTL ? "rotate-180" : ""
              }`}
            />
          </button>
        ))}
      </div>

      {/* SUB-MODALS FOR SETTING INTERACTIONS */}
      <AnimatePresence>
        {activeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveModal(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-md"
            />

            <motion.div
              initial={{ scale: 0.92, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.92, opacity: 0, y: 10 }}
              className="relative w-full max-w-sm rounded-3xl bg-neutral-950/95 border border-red-900/40 p-6 text-white shadow-2xl z-10 overflow-hidden backdrop-blur-xl"
            >
              {/* Modal Close Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <h3 className="font-bold text-lg text-white">
                  {activeModal === "account" && (isRTL ? "تعديل الحساب" : "Account Profile")}
                  {activeModal === "language" && (isRTL ? "اختر اللغة" : "Select Language")}
                  {activeModal === "appearance" && (isRTL ? "المظهر والثيم" : "Appearance")}
                  {activeModal === "notifications" && (isRTL ? "إعدادات الإشعارات" : "Notifications")}
                  {activeModal === "privacy" && (isRTL ? "الخصوصية وسجل البيانات" : "Privacy & Data")}
                  {activeModal === "password" && (isRTL ? "تغيير كلمة المرور" : "Change Password")}
                  {activeModal === "assistant" && (isRTL ? "تخصيص المساعد" : "Assistant Persona")}
                  {activeModal === "about" && (isRTL ? "معلومات التطبيق" : "About App")}
                </h3>
                <button
                  onClick={() => setActiveModal(null)}
                  className="p-1 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Contents based on type */}
              <div className="pt-4">
                {/* 1. Account */}
                {activeModal === "account" && (
                  <form onSubmit={handleSaveAccount} className="space-y-4">
                    <div>
                      <label className="block text-xs text-white/60 mb-1.5">
                        {isRTL ? "الاسم الكامل" : "Display Name"}
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-sm text-white focus:outline-none focus:border-red-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-white/60 mb-1.5">
                        {isRTL ? "البريد الإلكتروني" : "Email Address"}
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-sm text-white focus:outline-none focus:border-red-500"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium text-sm shadow-[0_0_20px_rgba(220,20,60,0.4)] active:scale-[0.98] transition-all"
                    >
                      {isRTL ? "حفظ التغييرات" : "Save Changes"}
                    </button>
                  </form>
                )}

                {/* 2. Language */}
                {activeModal === "language" && (
                  <div className="space-y-2">
                    <button
                      onClick={() => handleLanguageSelect("en")}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl border transition-all ${
                        user.preferredLanguage === "en"
                          ? "bg-red-950/60 border-red-500 text-white font-medium shadow-[0_0_15px_rgba(220,20,60,0.3)]"
                          : "bg-white/[0.03] border-white/10 text-white/70 hover:bg-white/[0.06] hover:text-white"
                      }`}
                    >
                      <span className="text-sm">English (US)</span>
                      {user.preferredLanguage === "en" && <Check className="w-4 h-4 text-red-400" />}
                    </button>
                    <button
                      onClick={() => handleLanguageSelect("ar")}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl border transition-all ${
                        user.preferredLanguage === "ar"
                          ? "bg-red-950/60 border-red-500 text-white font-medium shadow-[0_0_15px_rgba(220,20,60,0.3)]"
                          : "bg-white/[0.03] border-white/10 text-white/70 hover:bg-white/[0.06] hover:text-white"
                      }`}
                    >
                      <span className="text-sm">العربية (Arabic)</span>
                      {user.preferredLanguage === "ar" && <Check className="w-4 h-4 text-red-400" />}
                    </button>
                  </div>
                )}

                {/* 3. Appearance */}
                {activeModal === "appearance" && (
                  <div className="space-y-4">
                    <p className="text-xs text-white/60">
                      {isRTL
                        ? "يستخدم التطبيق سمة Crimson Obsidian الداكنة الحصرية مع التوهج الياقوتي ثلاثي الأبعاد."
                        : "The app uses the exclusive Crimson Obsidian dark theme with 3D Ruby neon luminescence."}
                    </p>
                    <div className="p-4 rounded-2xl bg-[#140205] border border-red-500/40 flex items-center justify-between">
                      <div className="flex items-center space-x-3 rtl:space-x-reverse">
                        <div className="w-6 h-6 rounded-full bg-red-600 shadow-[0_0_10px_#ef4444]" />
                        <span className="text-sm font-medium text-white">Crimson Dark Theme</span>
                      </div>
                      <span className="text-xs px-2.5 py-1 rounded-full bg-red-950 text-red-400 border border-red-500/30">
                        {isRTL ? "مُفعل" : "Active"}
                      </span>
                    </div>
                  </div>
                )}

                {/* 4. Notifications */}
                {activeModal === "notifications" && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.03] border border-white/10">
                      <div>
                        <div className="text-sm font-medium text-white">
                          {isRTL ? "إشعارات المحادثات" : "Push Alerts"}
                        </div>
                        <div className="text-xs text-white/50">
                          {isRTL ? "تنبيهات عند اكتمال الردود" : "Notify on AI responses"}
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={notificationsEnabled}
                        onChange={(e) => setNotificationsEnabled(e.target.checked)}
                        className="w-5 h-5 accent-red-600 rounded cursor-pointer"
                      />
                    </div>
                    <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.03] border border-white/10">
                      <div>
                        <div className="text-sm font-medium text-white">
                          {isRTL ? "المؤثرات الصوتية" : "Sound Effects"}
                        </div>
                        <div className="text-xs text-white/50">
                          {isRTL ? "أصوات النقر والردود الصوتية" : "Play audio cues & clicks"}
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={soundEffects}
                        onChange={(e) => setSoundEffects(e.target.checked)}
                        className="w-5 h-5 accent-red-600 rounded cursor-pointer"
                      />
                    </div>
                  </div>
                )}

                {/* 5. Privacy & Data */}
                {activeModal === "privacy" && (
                  <div className="space-y-4">
                    <p className="text-xs text-white/60">
                      {isRTL
                        ? "جميع محادثاتك وسجلاتك مشفرة محلياً. يمكنك مسح السجل بالكامل متى شئت."
                        : "All your conversations are locally saved & private. You can clear your session history anytime."}
                    </p>
                    <button
                      onClick={() => {
                        onClearHistory?.();
                        setActiveModal(null);
                        showToast(isRTL ? "تم مسح سجل المحادثات" : "Chat history wiped");
                      }}
                      className="w-full flex items-center justify-center space-x-2 rtl:space-x-reverse py-3 rounded-2xl bg-red-950/60 hover:bg-red-900/80 border border-red-500/40 text-red-300 hover:text-white text-xs font-semibold transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>{isRTL ? "مسح جميع سجلات المحادثات" : "Clear All Chat History"}</span>
                    </button>
                  </div>
                )}

                {/* 6. Password */}
                {activeModal === "password" && (
                  <form onSubmit={handlePasswordChange} className="space-y-3.5">
                    <div>
                      <label className="block text-xs text-white/60 mb-1.5">
                        {isRTL ? "كلمة المرور الحالية" : "Current Password"}
                      </label>
                      <input
                        type="password"
                        value={passwordOld}
                        onChange={(e) => setPasswordOld(e.target.value)}
                        placeholder="••••••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-sm text-white focus:outline-none focus:border-red-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-white/60 mb-1.5">
                        {isRTL ? "كلمة المرور الجديدة" : "New Password"}
                      </label>
                      <input
                        type="password"
                        value={passwordNew}
                        onChange={(e) => setPasswordNew(e.target.value)}
                        placeholder="••••••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-sm text-white focus:outline-none focus:border-red-500"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium text-sm shadow-[0_0_20px_rgba(220,20,60,0.4)] active:scale-[0.98] transition-all"
                    >
                      {passwordSuccess
                        ? isRTL ? "تم التحديث!" : "Updated!"
                        : isRTL ? "تحديث كلمة المرور" : "Update Password"}
                    </button>
                  </form>
                )}

                {/* 7. Assistant Personality & Voice */}
                {activeModal === "assistant" && (
                  <form onSubmit={handleSaveAssistant} className="space-y-4">
                    <div>
                      <label className="block text-xs text-white/60 mb-2">
                        {isRTL ? "شخصية المساعد" : "AI Persona Style"}
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: "balanced", label: isRTL ? "متوازن" : "Balanced" },
                          { id: "concise", label: isRTL ? "موجز وسريع" : "Concise" },
                          { id: "creative", label: isRTL ? "إبداعي" : "Creative" },
                          { id: "code", label: isRTL ? "مبرمج تقني" : "Code Expert" },
                        ].map((item) => (
                          <button
                            type="button"
                            key={item.id}
                            onClick={() => setPersonality(item.id as any)}
                            className={`p-2.5 rounded-xl border text-xs text-center transition-all ${
                              personality === item.id
                                ? "bg-red-950/70 border-red-500 text-white font-medium"
                                : "bg-white/[0.03] border-white/10 text-white/60 hover:text-white"
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs text-white/60 mb-2">
                        {isRTL ? "الصوت الذكي" : "Voice Accent"}
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: "Kore" as const, label: "Kore (Smooth)" },
                          { id: "Puck" as const, label: "Puck (Energetic)" },
                          { id: "Fenrir" as const, label: "Fenrir (Deep)" },
                          { id: "Zephyr" as const, label: "Zephyr (Soft)" },
                        ].map((v) => (
                          <button
                            type="button"
                            key={v.id}
                            onClick={() => setVoiceName(v.id)}
                            className={`p-2.5 rounded-xl border text-xs text-center transition-all ${
                              voiceName === v.id
                                ? "bg-red-950/70 border-red-500 text-white font-medium"
                                : "bg-white/[0.03] border-white/10 text-white/60 hover:text-white"
                            }`}
                          >
                            {v.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium text-sm shadow-[0_0_20px_rgba(220,20,60,0.4)] active:scale-[0.98] transition-all"
                    >
                      {isRTL ? "حفظ إعدادات المساعد" : "Save Assistant Preferences"}
                    </button>
                  </form>
                )}

                {/* 8. About App */}
                {activeModal === "about" && (
                  <div className="space-y-3 text-center py-2">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(220,20,60,0.5)]">
                      <SettingsIcon className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="text-base font-bold text-white">Crimson AI Assistant</h4>
                    <p className="text-xs text-white/60">
                      Version 1.0.0 (Production Build)
                      <br />
                      Powered by Google Gemini AI
                    </p>
                    <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10 text-left rtl:text-right text-[11px] text-white/50 space-y-1">
                      <div>• High-demand auto-fallback resilience</div>
                      <div>• Voice generation & Speech synthesis</div>
                      <div>• Multilingual Arabic & English support</div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
