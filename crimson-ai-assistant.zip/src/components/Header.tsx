import React from "react";
import { Menu, Wifi, Battery, Signal, Sparkles, MessageSquarePlus } from "lucide-react";
import { UserProfile } from "../types";

interface HeaderProps {
  user: UserProfile;
  onOpenSidebar: () => void;
  onOpenProfile: () => void;
  onNewChat?: () => void;
  hasMessages?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onOpenSidebar,
  onOpenProfile,
  onNewChat,
  hasMessages,
}) => {
  // Current time formatted like iPhone status bar
  const [timeStr, setTimeStr] = React.useState("9:41");

  React.useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, "0");
      setTimeStr(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header id="app-top-header" className="w-full flex flex-col z-30 select-none">
      {/* Sleek mobile status bar (time, dynamic island, indicators) */}
      <div className="w-full px-6 pt-3 pb-1 flex items-center justify-between text-xs text-white/80 font-medium tracking-tight">
        <span className="font-semibold text-white/90 pl-1">{timeStr}</span>
        
        {/* Dynamic Island Pill Notch */}
        <div className="w-24 h-4 bg-black/90 border border-white/10 rounded-full flex items-center justify-center space-x-1.5 shadow-inner">
          <div className="w-2.5 h-2.5 bg-neutral-900 rounded-full border border-neutral-800 flex items-center justify-center">
            <div className="w-1 h-1 bg-red-500/80 rounded-full animate-pulse" />
          </div>
          <div className="w-2 h-2 bg-neutral-900 rounded-full" />
        </div>

        {/* Status icons */}
        <div className="flex items-center space-x-1.5 text-white/90 pr-1">
          <Signal className="w-3.5 h-3.5 stroke-[2.5]" />
          <Wifi className="w-3.5 h-3.5 stroke-[2.5]" />
          <Battery className="w-4 h-4 stroke-[2.2] fill-white/80" />
        </div>
      </div>

      {/* Main Header Navigation Bar (Matches screenshot precisely) */}
      <div className="w-full px-6 py-3 flex items-center justify-between">
        {/* Left: 3-bar Hamburger Menu Button */}
        <button
          id="btn-sidebar-toggle"
          onClick={onOpenSidebar}
          aria-label="Open navigation menu"
          className="p-2 -ml-2 text-white/90 hover:text-white rounded-full hover:bg-white/10 active:scale-95 transition-all duration-200"
        >
          <Menu className="w-6 h-6 stroke-[2]" />
        </button>

        {/* Center: Title / Logo if in chat */}
        {hasMessages && (
          <div className="flex items-center space-x-1.5 px-3 py-1 bg-red-950/40 border border-red-500/20 rounded-full">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs font-medium text-red-200/90 tracking-wide">Crimson AI</span>
          </div>
        )}

        {/* Right action group */}
        <div className="flex items-center space-x-2">
          {hasMessages && onNewChat && (
            <button
              id="btn-new-chat-header"
              onClick={onNewChat}
              title="New Conversation"
              className="p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10 active:scale-95 transition-all"
            >
              <MessageSquarePlus className="w-5 h-5" />
            </button>
          )}

          {/* Right: User Avatar Photo Circle */}
          <button
            id="btn-user-profile"
            onClick={onOpenProfile}
            aria-label="User Profile"
            className="relative group p-0.5 rounded-full ring-2 ring-red-500/30 hover:ring-red-500/70 transition-all duration-200 active:scale-95"
          >
            <div className="w-9 h-9 rounded-full overflow-hidden bg-neutral-800 flex items-center justify-center text-sm font-semibold text-white">
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="bg-gradient-to-tr from-red-600 to-rose-400 w-full h-full flex items-center justify-center">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              )}
            </div>
            {/* Online Green dot */}
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-black rounded-full" />
          </button>
        </div>
      </div>
    </header>
  );
};
