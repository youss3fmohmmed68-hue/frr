import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Mic, MicOff, Volume2, Sparkles, PhoneOff } from "lucide-react";
import { RubyOrb } from "./RubyOrb";
import { OrbState } from "../types";

interface VoiceOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  orbState: OrbState;
  transcript: string;
  assistantResponse: string;
  isListening: boolean;
  onToggleMic: () => void;
  userName: string;
}

export const VoiceOverlay: React.FC<VoiceOverlayProps> = ({
  isOpen,
  onClose,
  orbState,
  transcript,
  assistantResponse,
  isListening,
  onToggleMic,
  userName,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          id="voice-mode-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-between p-6 select-none overflow-hidden"
          style={{
            background:
              "radial-gradient(ellipse at 50% 60%, rgba(180, 10, 30, 0.45), rgba(90, 0, 15, 0.3) 40%, #000000 85%)",
          }}
        >
          {/* Top Bar */}
          <div className="w-full flex items-center justify-between z-10">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <span className="text-xs font-semibold uppercase tracking-wider text-red-400">
                Live Voice Mode
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full text-white/60 hover:text-white bg-white/5 hover:bg-white/10 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Center Orb with dynamic audio wave pulses */}
          <div className="flex flex-col items-center justify-center space-y-8 my-auto z-10">
            <RubyOrb state={orbState} size="large" onClick={onToggleMic} />

            {/* Status caption */}
            <div className="text-center space-y-2 max-w-sm px-4">
              <motion.p
                key={orbState}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-lg font-medium text-white tracking-wide"
              >
                {orbState === "listening" && "Listening to you..."}
                {orbState === "thinking" && "Crimson is thinking..."}
                {orbState === "speaking" && "Crimson is answering..."}
                {orbState === "idle" && `Tap orb to speak with Crimson`}
              </motion.p>

              {/* Live Subtitle Transcript */}
              {(transcript || assistantResponse) && (
                <div className="p-3 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-md text-sm text-white/80 max-h-28 overflow-y-auto leading-relaxed">
                  {assistantResponse ? (
                    <p className="text-rose-200">{assistantResponse}</p>
                  ) : (
                    <p className="italic text-white/70">"{transcript}"</p>
                  )}
                </div>
              )}
            </div>

            {/* Audio Wave Frequency Bars */}
            <div className="flex items-center space-x-1.5 h-10">
              {[40, 70, 90, 60, 100, 75, 45, 85, 30].map((height, idx) => (
                <motion.span
                  key={idx}
                  className="w-1 rounded-full bg-gradient-to-t from-red-600 to-rose-400"
                  animate={{
                    height:
                      orbState === "listening" || orbState === "speaking"
                        ? [`${height * 0.3}%`, `${height}%`, `${height * 0.4}%`]
                        : "4px",
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 0.6 + (idx % 3) * 0.2,
                    ease: "easeInOut",
                  }}
                />
              ))}
            </div>
          </div>

          {/* Bottom Action Controls */}
          <div className="w-full flex items-center justify-center space-x-6 z-10 pb-4">
            <button
              onClick={onToggleMic}
              className={`p-4 rounded-full transition-all active:scale-95 shadow-xl ${
                isListening
                  ? "bg-red-600 text-white shadow-[0_0_25px_rgba(220,20,60,0.6)]"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
              title={isListening ? "Mute Microphone" : "Unmute Microphone"}
            >
              {isListening ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
            </button>

            <button
              onClick={onClose}
              className="p-4 rounded-full bg-neutral-900 text-red-500 border border-red-500/30 hover:bg-red-950/40 transition-all active:scale-95 shadow-xl"
              title="End Voice Call"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
