import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Crown, Check, Sparkles, Zap, Shield, Flame } from "lucide-react";

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
  isPremium?: boolean;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({
  isOpen,
  onClose,
  onUpgrade,
  isPremium,
}) => {
  const [selectedPlan, setSelectedPlan] = React.useState<"monthly" | "yearly">("yearly");

  const perks = [
    "Unlimited Gemini 3.7 Pro & Flash responses",
    "Ultra-low latency Live Voice conversations",
    "Smart Documents & PDF summarization",
    "Multi-lingual Voice cloning & accents",
    "Custom AI Personalities & Memory",
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            id="premium-upgrade-dialog"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#1c0207] via-neutral-950 to-neutral-950 border border-red-500/30 p-6 text-white shadow-2xl z-10 overflow-hidden"
          >
            {/* Ambient gold / red glow */}
            <div
              className="absolute -top-12 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full pointer-events-none opacity-30"
              style={{
                background: "radial-gradient(circle, #f59e0b 0%, #dc2626 50%, transparent 70%)",
                filter: "blur(40px)",
              }}
            />

            {/* Header */}
            <div className="relative flex items-center justify-between pb-3">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
                  <Crown className="w-5 h-5 fill-amber-400" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-white">Crimson Premium</h3>
                  <p className="text-xs text-amber-300/80">Next-gen AI capabilities</p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Perks List */}
            <div className="relative space-y-2.5 py-4">
              {perks.map((perk, index) => (
                <div key={index} className="flex items-center space-x-3 text-xs sm:text-sm text-neutral-200">
                  <div className="w-4 h-4 rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-red-400 stroke-[3]" />
                  </div>
                  <span>{perk}</span>
                </div>
              ))}
            </div>

            {/* Pricing selector */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedPlan("monthly")}
                className={`p-3 rounded-2xl border text-left transition-all relative ${
                  selectedPlan === "monthly"
                    ? "bg-red-950/60 border-red-500 shadow-[0_0_15px_rgba(220,20,60,0.3)]"
                    : "bg-white/[0.03] border-white/10 opacity-75 hover:opacity-100"
                }`}
              >
                <span className="block text-xs text-white/60">Monthly</span>
                <span className="text-lg font-bold text-white">$9.99</span>
                <span className="block text-[10px] text-white/40">billed monthly</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan("yearly")}
                className={`p-3 rounded-2xl border text-left transition-all relative ${
                  selectedPlan === "yearly"
                    ? "bg-red-950/60 border-red-500 shadow-[0_0_15px_rgba(220,20,60,0.3)]"
                    : "bg-white/[0.03] border-white/10 opacity-75 hover:opacity-100"
                }`}
              >
                <span className="absolute -top-2 right-2 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-red-500 text-[9px] font-bold text-black uppercase">
                  Save 40%
                </span>
                <span className="block text-xs text-white/60">Yearly</span>
                <span className="text-lg font-bold text-white">$5.99</span>
                <span className="block text-[10px] text-white/40">/month ($71.88/yr)</span>
              </button>
            </div>

            {/* Action button */}
            <div className="pt-5">
              <button
                onClick={() => {
                  onUpgrade();
                  onClose();
                }}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:brightness-110 text-white font-semibold text-sm shadow-[0_0_25px_rgba(220,20,60,0.4)] active:scale-[0.98] transition-all flex items-center justify-center space-x-2"
              >
                <Sparkles className="w-4 h-4 text-amber-200" />
                <span>{isPremium ? "Manage Subscription" : "Activate Premium Plan"}</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
