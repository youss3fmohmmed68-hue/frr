import React from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  X,
  Home,
  MessageSquare,
  History,
  FileText,
  Bell,
  Settings,
  HelpCircle,
  LogOut,
  Crown,
  ChevronRight,
} from "lucide-react";
import { UserProfile, MenuView } from "../types";

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  activeView: MenuView;
  onSelectView: (view: MenuView) => void;
  onOpenProfile: () => void;
  onOpenPremium: () => void;
  onLogout: () => void;
}

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  user,
  activeView,
  onSelectView,
  onOpenProfile,
  onOpenPremium,
  onLogout,
}) => {
  const isRTL = user.preferredLanguage === "ar";

  const menuItems: { id: MenuView; label: string; labelAr: string; icon: React.ReactNode }[] = [
    {
      id: "home",
      label: "Home",
      labelAr: "الرئيسية",
      icon: <Home className="w-5 h-5" />,
    },
    {
      id: "chats",
      label: "Chats",
      labelAr: "المحادثات",
      icon: <MessageSquare className="w-5 h-5" />,
    },
    {
      id: "history",
      label: "History",
      labelAr: "السجل",
      icon: <History className="w-5 h-5" />,
    },
    {
      id: "documents",
      label: "Documents",
      labelAr: "المستندات",
      icon: <FileText className="w-5 h-5" />,
    },
    {
      id: "reminders",
      label: "Reminders",
      labelAr: "التذكيرات",
      icon: <Bell className="w-5 h-5" />,
    },
    {
      id: "settings",
      label: "Settings",
      labelAr: "الإعدادات",
      icon: <Settings className="w-5 h-5" />,
    },
    {
      id: "help",
      label: "Help & Support",
      labelAr: "المساعدة والدعم",
      icon: <HelpCircle className="w-5 h-5" />,
    },
    {
      id: "logout" as any,
      label: "Log Out",
      labelAr: "تسجيل الخروج",
      icon: <LogOut className="w-5 h-5 text-red-400" />,
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Subtle Dark Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/65 backdrop-blur-[2px] z-40 transition-opacity"
          />

          {/* Drawer Menu Panel (Exact match to screenshot 1:1) */}
          <motion.aside
            id="sidebar-navigation-menu"
            dir={isRTL ? "rtl" : "ltr"}
            initial={{ x: isRTL ? "100%" : "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: isRTL ? "100%" : "-100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className={`fixed top-0 ${isRTL ? "right-0" : "left-0"} bottom-0 w-[82%] sm:w-[72%] max-w-[340px] z-50 flex flex-col justify-between p-5 sm:p-6 select-none overflow-y-auto no-scrollbar text-white shadow-[15px_0_50px_rgba(0,0,0,0.85)] ${isRTL ? "border-l" : "border-r"} border-red-950/40`}
            style={{
              background:
                "linear-gradient(180deg, #090103 0%, #120105 35%, #250208 75%, #34030d 100%)",
            }}
          >
            {/* Top section: Close Button + Glowing Avatar + Name & Email */}
            <div className="flex flex-col space-y-3 sm:space-y-4">
              {/* Close 'X' Button at top right/left */}
              <div className="flex justify-end w-full">
                <button
                  id="btn-close-menu"
                  onClick={onClose}
                  aria-label="Close menu"
                  className="p-1.5 text-white/70 hover:text-white rounded-full hover:bg-white/10 active:scale-95 transition-colors"
                >
                  <X className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2]" />
                </button>
              </div>

              {/* User Avatar with radiant crimson neon glow */}
              <div className="flex flex-col items-start space-y-2.5 pt-0.5">
                <button
                  id="btn-drawer-profile-avatar"
                  onClick={() => {
                    onOpenProfile();
                    onClose();
                  }}
                  className="relative group cursor-pointer"
                  title="Edit profile"
                >
                  {/* Glowing Ruby Aura around avatar */}
                  <div
                    className="absolute -inset-1 rounded-full pointer-events-none"
                    style={{
                      background:
                        "radial-gradient(circle, rgba(255, 30, 60, 0.9) 0%, rgba(220, 10, 30, 0.4) 60%, transparent 100%)",
                      filter: "blur(6px)",
                    }}
                  />

                  {/* Avatar circular frame */}
                  <div className="relative w-16 h-16 sm:w-18 sm:h-18 rounded-full overflow-hidden border-2 border-red-500/80 shadow-[0_0_20px_rgba(255,30,60,0.6)] bg-neutral-900 flex items-center justify-center">
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </button>

                {/* User Name & Email */}
                <div className="space-y-0.5 text-start">
                  <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                    {user.name}
                  </h2>
                  <p className="text-xs text-white/50 tracking-normal font-normal">
                    {user.email}
                  </p>
                </div>
              </div>

              {/* Navigation List Items */}
              <nav className="flex flex-col space-y-1 sm:space-y-1.5 pt-2 sm:pt-4">
                {menuItems.map((item) => {
                  const isActive = activeView === item.id;
                  const isLogout = item.id === ("logout" as any);

                  if (isLogout) {
                    return (
                      <button
                        key={item.id}
                        id="menu-item-logout"
                        onClick={() => {
                          onLogout();
                          onClose();
                        }}
                        className="w-full flex items-center space-x-3.5 rtl:space-x-reverse px-4 py-2 sm:py-2.5 rounded-full text-white/80 hover:text-white hover:bg-white/[0.04] transition-all text-xs sm:text-sm font-normal text-start"
                      >
                        <span className="text-white/70">{item.icon}</span>
                        <span>{isRTL ? item.labelAr : item.label}</span>
                      </button>
                    );
                  }

                  return (
                    <button
                      key={item.id}
                      id={`menu-item-${item.id}`}
                      onClick={() => {
                        onSelectView(item.id);
                        onClose();
                      }}
                      className={`w-full flex items-center space-x-3.5 rtl:space-x-reverse px-4 py-2 sm:py-2.5 rounded-full transition-all text-xs sm:text-sm font-normal text-start ${
                        isActive
                          ? "bg-gradient-to-r from-red-950/80 to-rose-950/30 border border-red-600/70 text-white font-medium shadow-[0_0_15px_rgba(220,20,60,0.25)]"
                          : "text-white/80 hover:text-white hover:bg-white/[0.04]"
                      }`}
                    >
                      <span
                        className={
                          isActive ? "text-red-500" : "text-white/70"
                        }
                      >
                        {item.icon}
                      </span>
                      <span>{isRTL ? item.labelAr : item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Bottom Upgrade to Premium Banner (Exact match to screenshot) */}
            <div className="pt-3 sm:pt-4 mt-2">
              <button
                id="btn-menu-upgrade-premium"
                onClick={() => {
                  onOpenPremium();
                  onClose();
                }}
                className="w-full flex items-center justify-between p-3 sm:p-3.5 rounded-2xl bg-gradient-to-r from-[#2a0208] via-[#38020b] to-[#250107] border border-red-500/25 hover:border-red-500/50 shadow-[0_4px_20px_rgba(0,0,0,0.6)] active:scale-[0.98] transition-all group text-start"
              >
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  {/* Golden Crown Icon */}
                  <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 group-hover:scale-105 transition-transform">
                    <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 fill-amber-400/20" />
                  </div>

                  <div className="space-y-0.5">
                    <h4 className="text-xs sm:text-sm font-medium text-white group-hover:text-amber-100 transition-colors">
                      {isRTL ? "ترقية إلى بريميوم" : "Upgrade to Premium"}
                    </h4>
                    <p className="text-[10px] sm:text-[11px] text-red-200/60 font-normal">
                      {isRTL ? "فتح كافة الميزات الذكية" : "Unlock more features"}
                    </p>
                  </div>
                </div>

                <ChevronRight className={`w-4 h-4 text-white/50 group-hover:text-white ${isRTL ? "rotate-180 group-hover:-translate-x-0.5" : "group-hover:translate-x-0.5"} transition-all`} />
              </button>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};
