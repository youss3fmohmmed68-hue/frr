import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, History, MessageSquare, Trash2, Search, Calendar } from "lucide-react";
import { ChatSession } from "../types";

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  onClearAll: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  sessions,
  onSelectSession,
  onDeleteSession,
  onClearAll,
}) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filtered = sessions.filter((s) =>
    s.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md rounded-3xl bg-neutral-950 border border-red-900/40 p-6 text-white shadow-2xl z-10 overflow-hidden flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-red-600/20 text-red-400">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-white">History</h3>
                  <p className="text-xs text-white/50">{sessions.length} recorded chats</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {sessions.length > 0 && (
                  <button
                    onClick={onClearAll}
                    className="text-[11px] text-red-400 hover:text-red-300 transition-colors"
                  >
                    Clear All
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Search */}
            <div className="relative my-3 shrink-0">
              <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search history..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-white/40 focus:outline-none focus:border-red-500"
              />
            </div>

            {/* Session list */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 pt-1">
              {filtered.length === 0 ? (
                <div className="p-8 text-center text-xs text-white/40">
                  No chat history found
                </div>
              ) : (
                filtered.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      onSelectSession(s.id);
                      onClose();
                    }}
                    className="p-3.5 rounded-2xl bg-white/[0.03] hover:bg-red-950/40 border border-white/5 hover:border-red-500/30 transition-all flex items-center justify-between cursor-pointer group"
                  >
                    <div className="flex items-center space-x-3 truncate">
                      <MessageSquare className="w-4 h-4 text-red-400 shrink-0" />
                      <div className="truncate">
                        <p className="text-xs text-white font-medium truncate">{s.title}</p>
                        <p className="text-[10px] text-white/40">
                          {new Date(s.createdAt).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })} • {s.messages.length} messages
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={(e) => onDeleteSession(s.id, e)}
                      className="p-1.5 text-white/40 hover:text-red-400 rounded-md transition-colors shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
