import React, { useEffect, useRef } from "react";
import Markdown from "react-markdown";
import { Copy, Check, Volume2, Sparkles, User, Bot } from "lucide-react";
import { ChatMessage } from "../types";
import { motion } from "motion/react";

interface ChatViewProps {
  messages: ChatMessage[];
  isThinking: boolean;
  onSpeakText: (text: string) => void;
  speakingMessageId: string | null;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  isThinking,
  onSpeakText,
  speakingMessageId,
}) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isThinking]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div
      id="chat-messages-container"
      className="flex-1 w-full max-w-xl mx-auto px-4 py-2 overflow-y-auto space-y-4 scroll-smooth"
    >
      {messages.map((msg, index) => {
        const isUser = msg.role === "user";
        const isSpeaking = speakingMessageId === msg.id;

        return (
          <motion.div
            key={msg.id}
            id={`message-row-${msg.id}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: index === messages.length - 1 ? 0.05 : 0 }}
            className={`flex flex-col ${isUser ? "items-end" : "items-start"} w-full`}
          >
            {/* Bubble */}
            <div
              className={`relative max-w-[88%] sm:max-w-[82%] px-4 py-3 rounded-2xl text-sm md:text-base leading-relaxed ${
                isUser
                  ? "bg-gradient-to-br from-red-600 to-rose-700 text-white rounded-br-sm shadow-[0_4px_20px_rgba(220,20,60,0.3)]"
                  : "bg-black/60 backdrop-blur-xl border border-white/10 text-neutral-100 rounded-bl-sm shadow-[0_8px_30px_rgba(0,0,0,0.6)]"
              }`}
            >
              {/* Message Header for Model */}
              {!isUser && (
                <div className="flex items-center space-x-1.5 mb-1.5 text-xs text-red-400 font-semibold tracking-wide">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Crimson AI</span>
                </div>
              )}

              {/* Message Content */}
              <div className="markdown-body prose prose-invert max-w-none text-white/95 break-words">
                <Markdown>{msg.content}</Markdown>
              </div>

              {/* Action Toolbar for AI message */}
              {!isUser && (
                <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-xs text-white/60">
                  <span className="text-[11px] text-white/40">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>

                  <div className="flex items-center space-x-1.5">
                    {/* TTS Button */}
                    <button
                      id={`btn-speak-${msg.id}`}
                      onClick={() => onSpeakText(msg.content)}
                      className={`p-1 rounded-md hover:bg-white/10 transition-colors ${
                        isSpeaking ? "text-red-400 animate-pulse bg-red-500/20" : "text-white/70"
                      }`}
                      title="Read aloud"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Copy Button */}
                    <button
                      id={`btn-copy-${msg.id}`}
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="p-1 rounded-md hover:bg-white/10 text-white/70 transition-colors"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        );
      })}

      {/* Thinking / Typing Indicator */}
      {isThinking && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center space-x-2 px-4 py-3 rounded-2xl bg-black/60 border border-white/10 max-w-[140px] text-white/70"
        >
          <div className="w-2 h-2 rounded-full bg-red-500 animate-bounce" />
          <div className="w-2 h-2 rounded-full bg-red-400 animate-bounce [animation-delay:150ms]" />
          <div className="w-2 h-2 rounded-full bg-rose-400 animate-bounce [animation-delay:300ms]" />
          <span className="text-xs text-white/60 ml-1">Thinking...</span>
        </motion.div>
      )}

      <div ref={bottomRef} className="h-2" />
    </div>
  );
};
