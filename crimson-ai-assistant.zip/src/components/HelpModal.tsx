import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, HelpCircle, Mic, Sparkles, MessageSquare, ShieldCheck, Mail } from "lucide-react";

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  const faqs = [
    {
      q: "How does the Ruby Orb Voice Mode work?",
      a: "Tap the 3D Ruby Orb or the waveform icon at the bottom. Speak naturally, and Crimson AI will listen, think, and reply with audio and text.",
    },
    {
      q: "Which AI model is powering Crimson?",
      a: "Crimson is powered by Google's latest Gemini 3.7 Flash model, configured for lightning-fast multi-turn reasoning and audio synthesis.",
    },
    {
      q: "Can I use Crimson in Arabic and English?",
      a: "Yes! Crimson fully understands and speaks fluent Arabic (العربية) and English. You can switch preferences in Settings.",
    },
    {
      q: "Is my data stored securely?",
      a: "Your chats, profile, and reminders are stored locally in your browser and processed securely without third-party tracking.",
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md rounded-3xl bg-neutral-950 border border-red-900/40 p-6 text-white shadow-2xl z-10 overflow-hidden flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-red-600/20 text-red-400">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-white">Help & Support</h3>
                  <p className="text-xs text-white/50">Guides, FAQs & assistance</p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 py-3">
              {faqs.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1.5">
                  <h4 className="text-xs font-semibold text-red-300 flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{item.q}</span>
                  </h4>
                  <p className="text-xs text-white/70 leading-relaxed">{item.a}</p>
                </div>
              ))}

              {/* Support contact card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/50 to-neutral-900 border border-red-500/20 flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-xs font-medium text-white">Need personal help?</span>
                  <p className="text-[11px] text-white/50">support@crimsonai.app</p>
                </div>
                <div className="p-2 rounded-xl bg-red-600/20 text-red-400">
                  <Mail className="w-4 h-4" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
