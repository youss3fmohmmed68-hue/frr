import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, User, Check, Mail, Sliders, Globe, Volume2 } from "lucide-react";
import { UserProfile } from "../types";

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onSave: (updated: Partial<UserProfile>) => void;
}

const AVATAR_OPTIONS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onSave,
}) => {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email || "tanvir@example.com");
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [personality, setPersonality] = useState(user.personality);
  const [preferredLanguage, setPreferredLanguage] = useState(user.preferredLanguage);
  const [voiceName, setVoiceName] = useState(user.voiceName);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      email,
      avatarUrl,
      personality,
      preferredLanguage,
      voiceName,
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            id="user-profile-dialog"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-sm rounded-3xl bg-neutral-950 border border-red-900/40 p-6 text-white shadow-2xl z-10 overflow-hidden max-h-[85vh] overflow-y-auto"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center space-x-2">
                <User className="w-5 h-5 text-red-500" />
                <h3 className="font-semibold text-lg text-white">Settings & Profile</h3>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded-full text-white/60 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              {/* Avatar Selection */}
              <div>
                <label className="block text-xs font-medium text-white/70 mb-2">
                  Select Profile Avatar
                </label>
                <div className="flex items-center space-x-3">
                  {AVATAR_OPTIONS.map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setAvatarUrl(img)}
                      className={`relative w-12 h-12 rounded-full overflow-hidden border-2 transition-transform ${
                        avatarUrl === img
                          ? "border-red-500 scale-110 shadow-lg shadow-red-500/40"
                          : "border-white/20 opacity-70 hover:opacity-100"
                      }`}
                    >
                      <img src={img} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      {avatarUrl === img && (
                        <div className="absolute inset-0 bg-red-600/30 flex items-center justify-center">
                          <Check className="w-4 h-4 text-white drop-shadow" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* User Name */}
              <div>
                <label className="block text-xs font-medium text-white/70 mb-1.5">
                  Display Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Tanvir Ahmed"
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/40 focus:outline-none focus:border-red-500 transition-colors text-sm"
                />
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-medium text-white/70 mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tanvir@example.com"
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/40 focus:outline-none focus:border-red-500 transition-colors text-sm"
                />
              </div>

              {/* Assistant Tone */}
              <div>
                <label className="block text-xs font-medium text-white/70 mb-1.5">
                  Assistant Tone & Style
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: "balanced", label: "Balanced & Warm" },
                    { key: "concise", label: "Direct & Brief" },
                    { key: "creative", label: "Creative & Rich" },
                    { key: "code", label: "Technical & Code" },
                  ].map((item) => (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setPersonality(item.key as any)}
                      className={`p-2.5 rounded-xl border text-xs text-left transition-all ${
                        personality === item.key
                          ? "bg-red-950/60 border-red-500 text-white font-medium shadow-[0_0_10px_rgba(220,20,60,0.3)]"
                          : "bg-white/[0.02] border-white/10 text-white/60 hover:text-white"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Preferred Language */}
              <div>
                <label className="block text-xs font-medium text-white/70 mb-1.5">
                  Primary Language
                </label>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => setPreferredLanguage("en")}
                    className={`flex-1 py-2 rounded-xl text-xs font-medium border ${
                      preferredLanguage === "en"
                        ? "bg-red-600 border-red-500 text-white"
                        : "bg-white/5 border-white/10 text-white/60"
                    }`}
                  >
                    English (US)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreferredLanguage("ar")}
                    className={`flex-1 py-2 rounded-xl text-xs font-medium border ${
                      preferredLanguage === "ar"
                        ? "bg-red-600 border-red-500 text-white"
                        : "bg-white/5 border-white/10 text-white/60"
                    }`}
                  >
                    العربية (Arabic)
                  </button>
                </div>
              </div>

              {/* Submit */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium shadow-lg hover:brightness-110 active:scale-[0.98] transition-all"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
