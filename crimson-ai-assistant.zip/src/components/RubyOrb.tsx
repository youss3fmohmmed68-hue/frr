import React from "react";
import { motion } from "motion/react";
import { OrbState } from "../types";

interface RubyOrbProps {
  state: OrbState;
  onClick?: () => void;
  size?: "large" | "medium" | "compact" | "avatar" | "tiny";
  className?: string;
  children?: React.ReactNode;
}

export const RubyOrb: React.FC<RubyOrbProps> = ({
  state,
  onClick,
  size = "large",
  className = "",
  children,
}) => {
  // Dimensions based on size
  const sizeClasses = {
    large: "w-36 h-36 sm:w-44 sm:h-44 md:w-48 md:h-48",
    medium: "w-28 h-28 sm:w-32 sm:h-32",
    compact: "w-16 h-16 sm:w-20 sm:h-20",
    avatar: "w-10 h-10",
    tiny: "w-7 h-7",
  }[size];

  // Glow aura variants based on state
  const glowColors = {
    idle: "rgba(220, 20, 45, 0.45)",
    listening: "rgba(255, 40, 70, 0.75)",
    thinking: "rgba(230, 0, 60, 0.65)",
    speaking: "rgba(255, 60, 90, 0.7)",
  }[state];

  const haloSize = {
    large: "240px",
    medium: "180px",
    compact: "110px",
    avatar: "60px",
    tiny: "42px",
  }[size];

  return (
    <div
      id="ruby-orb-container"
      onClick={onClick}
      className={`relative flex items-center justify-center cursor-pointer select-none group ${className}`}
    >
      {/* Outer ambient pulsing halo layers */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: haloSize,
          height: haloSize,
          background: `radial-gradient(circle, ${glowColors} 0%, rgba(200, 10, 30, 0.15) 50%, rgba(0, 0, 0, 0) 75%)`,
          filter: "blur(12px)",
        }}
        animate={{
          scale: state === "listening" ? [1, 1.35, 1] : state === "speaking" ? [1, 1.25, 1.05, 1.2] : [0.95, 1.08, 0.95],
          opacity: state === "listening" ? [0.7, 1, 0.7] : [0.5, 0.85, 0.5],
        }}
        transition={{
          repeat: Infinity,
          duration: state === "listening" ? 1.5 : state === "thinking" ? 1.8 : 3.2,
          ease: "easeInOut",
        }}
      />

      {/* Ripple waves when listening */}
      {state === "listening" && (
        <>
          {[0, 1, 2].map((index) => (
            <motion.div
              key={index}
              className="absolute rounded-full border border-red-500/60 pointer-events-none"
              style={{
                width: size === "large" ? "170px" : "110px",
                height: size === "large" ? "170px" : "110px",
              }}
              initial={{ scale: 0.9, opacity: 0.8 }}
              animate={{ scale: 2.2, opacity: 0 }}
              transition={{
                repeat: Infinity,
                duration: 2.2,
                delay: index * 0.7,
                ease: "easeOut",
              }}
            />
          ))}
        </>
      )}

      {/* Main 3D Spherical Orb */}
      <motion.div
        id="ruby-orb-sphere"
        className={`relative rounded-full shadow-2xl overflow-hidden ${sizeClasses}`}
        style={{
          // Deep ruby metallic red gradient base
          background: "radial-gradient(circle at 35% 30%, #ff4d6d 0%, #d90429 25%, #9b001c 55%, #59000f 80%, #200005 100%)",
          boxShadow: `
            0 0 45px 12px ${glowColors},
            inset 0 0 25px 5px rgba(0, 0, 0, 0.85),
            inset 0 10px 20px 2px rgba(255, 180, 190, 0.65),
            inset 0 -12px 25px 4px rgba(60, 0, 10, 0.9)
          `,
        }}
        animate={{
          scale:
            state === "listening"
              ? [1, 1.08, 0.98, 1.05, 1]
              : state === "speaking"
              ? [1, 1.06, 1.02, 1.08, 1]
              : state === "thinking"
              ? [1, 1.03, 1]
              : [1, 1.04, 1],
          y: state === "idle" ? [0, -6, 0] : [0, -2, 0],
        }}
        transition={{
          repeat: Infinity,
          duration: state === "listening" ? 1.4 : state === "thinking" ? 1.2 : 3.5,
          ease: "easeInOut",
        }}
      >
        {/* Inner Dark Concave Iris / Core Refraction (Exact match to reference photo) */}
        <div
          className="absolute inset-[15%] rounded-full"
          style={{
            background: "radial-gradient(circle at 45% 45%, #0a0102 35%, #47010a 70%, #90041b 95%)",
            boxShadow: "inset 0 0 18px 6px rgba(0, 0, 0, 0.95), 0 0 12px 2px rgba(255, 60, 90, 0.35)",
          }}
        >
          {/* Internal ruby specular glow */}
          <div
            className="absolute bottom-2 right-3 w-8 h-8 rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(255, 75, 100, 0.7) 0%, rgba(200, 10, 30, 0) 70%)",
              filter: "blur(2px)",
            }}
          />

          {/* Optional Centered Icon / Content (e.g., Settings Cog) */}
          {children && (
            <div className="absolute inset-0 flex items-center justify-center z-10 text-red-500 drop-shadow-[0_0_8px_rgba(255,50,70,0.8)]">
              {children}
            </div>
          )}
        </div>

        {/* Top-crescent glossy highlight */}
        <div
          className="absolute top-2.5 left-1/2 -translate-x-1/2 w-[70%] h-[32%] rounded-[50%]"
          style={{
            background: "linear-gradient(180deg, rgba(255, 255, 255, 0.75) 0%, rgba(255, 190, 205, 0.25) 55%, transparent 100%)",
            filter: "blur(1px)",
          }}
        />

        {/* Bottom subtle secondary rim reflection */}
        <div
          className="absolute bottom-2 left-1/2 -translate-x-1/2 w-[60%] h-[20%] rounded-[50%]"
          style={{
            background: "radial-gradient(ellipse at center, rgba(255, 100, 130, 0.5) 0%, transparent 80%)",
            filter: "blur(2px)",
          }}
        />

        {/* Interactive thinking spinner reflection */}
        {state === "thinking" && (
          <motion.div
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              background: "conic-gradient(from 0deg, transparent 0deg, rgba(255, 255, 255, 0.4) 90deg, transparent 180deg)",
            }}
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1.8, ease: "linear" }}
          />
        )}
      </motion.div>
    </div>
  );
};
