import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, FileText, Plus, Trash2, Search, Download, Sparkles } from "lucide-react";
import { AIDocument } from "../types";
import { loadUserDocs, saveUserDocs } from "../utils/userStorage";

interface DocumentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAskAboutDoc: (content: string) => void;
  userKey?: string;
}

export const DocumentsModal: React.FC<DocumentsModalProps> = ({
  isOpen,
  onClose,
  onAskAboutDoc,
  userKey = "guest",
}) => {
  const [docs, setDocs] = useState<AIDocument[]>(() => loadUserDocs(userKey));
  const [searchTerm, setSearchTerm] = useState("");
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  // Reload when user changes
  useEffect(() => {
    setDocs(loadUserDocs(userKey));
  }, [userKey]);

  // Persist when documents change
  useEffect(() => {
    saveUserDocs(userKey, docs);
  }, [userKey, docs]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const newDoc: AIDocument = {
      id: "doc-" + Date.now(),
      title: newTitle.trim(),
      content: newContent.trim() || "No content provided yet.",
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      size: `${((newContent.length + 50) / 1024).toFixed(1)} KB`,
    };
    setDocs([newDoc, ...docs]);
    setNewTitle("");
    setNewContent("");
    setIsCreating(false);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDocs(docs.filter((d) => d.id !== id));
  };

  const filtered = docs.filter((d) =>
    d.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-lg rounded-3xl bg-neutral-950 border border-red-900/40 p-6 text-white shadow-2xl z-10 overflow-hidden flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-red-600/20 text-red-400">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-white">Documents</h3>
                  <p className="text-xs text-white/50">Manage AI generated docs & notes</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsCreating(!isCreating)}
                  className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-medium flex items-center space-x-1.5 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>New</span>
                </button>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Create Doc Form */}
            {isCreating && (
              <form onSubmit={handleCreate} className="p-4 my-3 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3 shrink-0">
                <input
                  type="text"
                  placeholder="Document Title (e.g., Summary.md)"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white text-sm focus:outline-none focus:border-red-500"
                />
                <textarea
                  placeholder="Paste or write notes for AI..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white text-sm focus:outline-none focus:border-red-500 resize-none"
                />
                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsCreating(false)}
                    className="px-3 py-1.5 rounded-lg text-xs text-white/60 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-xs font-medium text-white"
                  >
                    Save Document
                  </button>
                </div>
              </form>
            )}

            {/* Search Bar */}
            <div className="relative my-3 shrink-0">
              <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search documents..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-white/40 focus:outline-none focus:border-red-500"
              />
            </div>

            {/* Documents List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filtered.length === 0 ? (
                <div className="p-8 text-center text-xs text-white/40">
                  No documents found
                </div>
              ) : (
                filtered.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-3.5 rounded-2xl bg-white/[0.02] hover:bg-red-950/30 border border-white/5 hover:border-red-500/30 transition-all flex items-center justify-between group cursor-pointer"
                    onClick={() => {
                      onAskAboutDoc(`Analyze this document:\n\nTitle: ${doc.title}\n\nContent:\n${doc.content}`);
                      onClose();
                    }}
                  >
                    <div className="flex items-center space-x-3 truncate pr-2">
                      <div className="p-2 rounded-lg bg-white/5 text-red-400 group-hover:bg-red-600/20">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div className="truncate">
                        <h4 className="text-sm font-medium text-white truncate">{doc.title}</h4>
                        <p className="text-[11px] text-white/40">{doc.date} • {doc.size}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAskAboutDoc(`Please summarize and extract key insights from ${doc.title}:\n\n${doc.content}`);
                          onClose();
                        }}
                        className="px-2.5 py-1 rounded-md bg-white/5 hover:bg-red-600/30 text-[11px] text-red-300 flex items-center space-x-1 transition-colors"
                        title="Analyze with AI"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Ask AI</span>
                      </button>
                      <button
                        onClick={(e) => handleDelete(doc.id, e)}
                        className="p-1.5 text-white/40 hover:text-red-400 rounded-md transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
