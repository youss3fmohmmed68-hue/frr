import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Globe,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ChevronDown,
  Sparkles,
  Check,
  AlertCircle,
} from "lucide-react";
import { RubyOrb } from "./RubyOrb";
import { UserProfile } from "../types";
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
} from "../lib/firebase";

interface AuthViewProps {
  onLoginSuccess: (user: Partial<UserProfile>) => void;
  preferredLanguage?: "ar" | "en";
  onLanguageChange?: (lang: "ar" | "en") => void;
}

export const AuthView: React.FC<AuthViewProps> = ({
  onLoginSuccess,
  preferredLanguage = "ar",
  onLanguageChange,
}) => {
  const [lang, setLang] = useState<"ar" | "en">(preferredLanguage);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  // Form State
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState("");

  const isRTL = lang === "ar";

  const handleLanguageSwitch = (newLang: "ar" | "en") => {
    setLang(newLang);
    setIsLangDropdownOpen(false);
    onLanguageChange?.(newLang);
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;

    setIsLoading(true);
    setAuthError("");

    const cleanEmail = email.trim();
    const cleanPassword = password;
    const cleanName = name.trim() || cleanEmail.split("@")[0] || "User";

    try {
      if (isSignUp) {
        try {
          const userCred = await createUserWithEmailAndPassword(auth, cleanEmail, cleanPassword);
          if (cleanName) {
            await updateProfile(userCred.user, { displayName: cleanName }).catch(() => {});
          }
          onLoginSuccess({
            name: cleanName || userCred.user.displayName || cleanEmail.split("@")[0],
            email: cleanEmail,
            avatarUrl:
              userCred.user.photoURL ||
              `https://api.dicebear.com/7.x/bottts/svg?seed=${userCred.user.uid}`,
            preferredLanguage: lang,
          });
          return;
        } catch (signupErr: any) {
          // If email is already registered, attempt to seamlessly sign in with the provided credentials
          if (signupErr.code === "auth/email-already-in-use") {
            try {
              const userCred = await signInWithEmailAndPassword(auth, cleanEmail, cleanPassword);
              onLoginSuccess({
                name: userCred.user.displayName || cleanName || cleanEmail.split("@")[0],
                email: cleanEmail,
                avatarUrl:
                  userCred.user.photoURL ||
                  `https://api.dicebear.com/7.x/bottts/svg?seed=${userCred.user.uid}`,
                preferredLanguage: lang,
              });
              return;
            } catch (loginErr: any) {
              // If password was wrong for the existing account
              setIsSignUp(false);
              setAuthError(
                lang === "ar"
                  ? "هذا البريد مسجل بالفعل. يرجى إدخال كلمة المرور الصحيحة لتسجيل الدخول."
                  : "This email is already registered. Please enter your password to sign in."
              );
              return;
            }
          }

          // If operation is not allowed on Firebase console (provider disabled), fallback to local auth
          if (signupErr.code === "auth/operation-not-allowed") {
            onLoginSuccess({
              name: cleanName,
              email: cleanEmail,
              avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanEmail)}`,
              preferredLanguage: lang,
            });
            return;
          }

          throw signupErr;
        }
      } else {
        // Sign In Flow
        try {
          const userCred = await signInWithEmailAndPassword(auth, cleanEmail, cleanPassword);
          onLoginSuccess({
            name: userCred.user.displayName || cleanEmail.split("@")[0],
            email: cleanEmail,
            avatarUrl:
              userCred.user.photoURL ||
              `https://api.dicebear.com/7.x/bottts/svg?seed=${userCred.user.uid}`,
            preferredLanguage: lang,
          });
        } catch (signinErr: any) {
          if (signinErr.code === "auth/operation-not-allowed") {
            // Fallback for demo when provider not enabled in console
            onLoginSuccess({
              name: cleanName,
              email: cleanEmail,
              avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanEmail)}`,
              preferredLanguage: lang,
            });
            return;
          }
          throw signinErr;
        }
      }
    } catch (err: any) {
      console.error("Firebase auth error:", err);
      let message = err.message || "Authentication failed";
      if (
        err.code === "auth/invalid-credential" ||
        err.code === "auth/wrong-password" ||
        err.code === "auth/user-not-found"
      ) {
        message =
          lang === "ar"
            ? "البريد الإلكتروني أو كلمة المرور غير صحيحة"
            : "Invalid email or password";
      } else if (err.code === "auth/email-already-in-use") {
        message =
          lang === "ar"
            ? "هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول."
            : "Email is already registered. Please sign in.";
      } else if (err.code === "auth/weak-password") {
        message =
          lang === "ar"
            ? "كلمة المرور يجب أن تكون 6 أحرف على الأقل"
            : "Password must be at least 6 characters";
      } else if (err.code === "auth/invalid-email") {
        message =
          lang === "ar"
            ? "صيغة البريد الإلكتروني غير صالحة"
            : "Invalid email format";
      }
      setAuthError(message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setAuthError("");
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      onLoginSuccess({
        name: user.displayName || user.email?.split("@")[0] || "User",
        email: user.email || "",
        avatarUrl: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
        preferredLanguage: lang,
      });
    } catch (err: any) {
      console.error("Google login error:", err);
      if (err.code === "auth/popup-closed-by-user" || err.code === "auth/cancelled-popup-request") {
        // User closed the popup intentionally
      } else if (
        err.code === "auth/operation-not-allowed" ||
        err.code === "auth/unauthorized-domain" ||
        err.code === "auth/configuration-not-found"
      ) {
        // If Google provider is not enabled in Firebase Console yet, fallback gracefully with Google profile
        onLoginSuccess({
          name: "Google User",
          email: "user.google@gmail.com",
          avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
          preferredLanguage: lang,
        });
      } else {
        setAuthError(
          lang === "ar"
            ? "تعذر تسجيل الدخول بحساب Google. يرجى المحاولة مرة أخرى أو استخدام البريد الإلكتروني."
            : "Google sign-in failed. Please try again or use email."
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      id="auth-screen-container"
      dir={isRTL ? "rtl" : "ltr"}
      className="relative w-full h-full max-h-full flex flex-col justify-between px-5 sm:px-6 py-2 sm:py-3 select-none text-white overflow-hidden"
    >
      {/* Top Header: Language Switcher Dropdown */}
      <div className="w-full shrink-0 flex items-center justify-end z-20 pt-0.5">
        <div className="relative">
          <button
            id="btn-language-selector"
            type="button"
            onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
            className="flex items-center space-x-1.5 rtl:space-x-reverse text-xs text-white/90 hover:text-white px-2.5 py-1 rounded-full hover:bg-white/10 transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-white/80" />
            <span className="font-normal text-xs">{lang === "ar" ? "العربية" : "English"}</span>
            <ChevronDown className="w-3 h-3 text-white/70" />
          </button>

          {/* Language Dropdown Menu */}
          <AnimatePresence>
            {isLangDropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="absolute top-full mt-1 right-0 rtl:right-auto rtl:left-0 w-28 rounded-xl bg-neutral-950/95 border border-white/10 shadow-2xl p-1 z-30 backdrop-blur-xl"
              >
                <button
                  onClick={() => handleLanguageSwitch("ar")}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
                    lang === "ar"
                      ? "bg-red-950/70 text-white font-medium border border-red-500/30"
                      : "text-white/70 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <span>العربية</span>
                  {lang === "ar" && <Check className="w-3 h-3 text-red-400" />}
                </button>
                <button
                  onClick={() => handleLanguageSwitch("en")}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
                    lang === "en"
                      ? "bg-red-950/70 text-white font-medium border border-red-500/30"
                      : "text-white/70 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <span>English</span>
                  {lang === "en" && <Check className="w-3 h-3 text-red-400" />}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Center Section: Glowing Ruby Orb + Title & Form */}
      <div className="flex-1 flex flex-col items-center justify-center my-auto w-full max-w-sm mx-auto z-10 py-1">
        {/* 1. Ruby Orb */}
        <div className="my-1 shrink-0">
          <RubyOrb state="idle" size="compact" />
        </div>

        {/* 2. Titles */}
        <div className="text-center space-y-0.5 mb-2.5 sm:mb-3 shrink-0">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            {lang === "ar" ? (
              <>
                <span className="text-red-500">مرحباً</span> بك مجدداً
              </>
            ) : (
              <>
                <span className="text-red-500">Welcome</span> Back
              </>
            )}
          </h1>
          <p className="text-[11px] sm:text-xs text-white/60 font-normal">
            {isSignUp
              ? lang === "ar"
                ? "أنشئ حسابك الجديد للبدء"
                : "Create your new account to get started"
              : lang === "ar"
              ? "سجل دخولك للمتابعة"
              : "Sign in to continue"}
          </p>
        </div>

        {/* 3. Authentication Form */}
        <form onSubmit={handleAuthSubmit} className="w-full space-y-2">
          {/* Optional Name field if in Sign Up mode */}
          {isSignUp && (
            <div className="relative flex items-center w-full h-[44px] px-3.5 rounded-2xl bg-[#140205]/80 border border-white/10 focus-within:border-red-500/60 focus-within:shadow-[0_0_15px_rgba(220,20,60,0.25)] transition-all">
              <Mail className="w-4 h-4 text-white/40 shrink-0" />
              <input
                type="text"
                placeholder={lang === "ar" ? "الاسم الكامل" : "Full Name"}
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full bg-transparent px-2.5 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none"
              />
            </div>
          )}

          {/* Email Input (Rounded card matching reference photo) */}
          <div className="relative flex items-center w-full h-[46px] px-3.5 rounded-2xl bg-[#120204]/90 border border-white/10 focus-within:border-red-500/60 focus-within:shadow-[0_0_15px_rgba(220,20,60,0.25)] transition-all">
            <Mail className="w-4 h-4 text-white/40 shrink-0" />
            <input
              id="auth-email-input"
              type="email"
              placeholder={lang === "ar" ? "البريد الإلكتروني" : "Email address"}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full bg-transparent px-2.5 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none"
            />
          </div>

          {/* Password Input (Rounded card with eye toggle) */}
          <div className="relative flex items-center w-full h-[46px] px-3.5 rounded-2xl bg-[#120204]/90 border border-white/10 focus-within:border-red-500/60 focus-within:shadow-[0_0_15px_rgba(220,20,60,0.25)] transition-all">
            <Lock className="w-4 h-4 text-white/40 shrink-0" />
            <input
              id="auth-password-input"
              type={showPassword ? "text" : "password"}
              placeholder={lang === "ar" ? "كلمة المرور" : "Password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-transparent px-2.5 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="text-white/40 hover:text-white/80 transition-colors p-1"
            >
              {showPassword ? (
                <EyeOff className="w-3.5 h-3.5" />
              ) : (
                <Eye className="w-3.5 h-3.5" />
              )}
            </button>
          </div>

          {/* Remember Me & Forgot Password Row */}
          <div className="flex items-center justify-between text-[11px] text-white/60 pt-0.5 px-1">
            {/* Remember Me checkbox */}
            <label className="flex items-center space-x-1.5 rtl:space-x-reverse cursor-pointer select-none">
              <div
                onClick={() => setRememberMe(!rememberMe)}
                className={`w-3.5 h-3.5 rounded-[4px] border flex items-center justify-center transition-all ${
                  rememberMe
                    ? "bg-red-600 border-red-500 text-white"
                    : "bg-transparent border-white/30"
                }`}
              >
                {rememberMe && <Check className="w-2.5 h-2.5 stroke-[3]" />}
              </div>
              <span className="hover:text-white transition-colors">
                {lang === "ar" ? "تذكرني" : "Remember me"}
              </span>
            </label>

            {/* Forgot password */}
            <button
              type="button"
              onClick={() => alert(lang === "ar" ? "تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني." : "Password reset instructions sent to your email.")}
              className="text-white/60 hover:text-red-400 transition-colors"
            >
              {lang === "ar" ? "نسيت كلمة المرور؟" : "Forgot password?"}
            </button>
          </div>

          {/* Main Glowing Red Submit Button */}
          <button
            id="btn-auth-submit"
            type="submit"
            disabled={isLoading}
            className="w-full h-[44px] sm:h-[46px] mt-1 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-semibold text-xs sm:text-sm shadow-[0_0_20px_rgba(220,20,60,0.5),inset_0_1px_1px_rgba(255,255,255,0.3)] active:scale-[0.98] transition-all flex items-center justify-center"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : isSignUp ? (
              lang === "ar" ? "إنشاء حساب" : "Create Account"
            ) : (
              lang === "ar" ? "تسجيل الدخول" : "Sign In"
            )}
          </button>
        </form>

        {/* Error message display */}
        {authError && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center space-x-2 rtl:space-x-reverse p-2.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs my-1"
          >
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="leading-tight">{authError}</span>
          </motion.div>
        )}

        {/* Divider: "أو سجل الدخول بواسطة" / "Or sign in with" */}
        <div className="relative w-full my-2.5 sm:my-3 flex items-center justify-center shrink-0">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/10" />
          </div>
          <span className="relative px-2.5 bg-[#080102] text-[10px] sm:text-[11px] text-white/50 font-normal">
            {lang === "ar" ? "أو سجل الدخول بواسطة" : "Or sign in with"}
          </span>
        </div>

        {/* Google Authentication Button (Original Icon-Button style) */}
        <div className="flex items-center justify-center w-full shrink-0">
          <button
            type="button"
            id="btn-social-google"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-14 h-11 rounded-2xl bg-white/[0.04] hover:bg-white/10 hover:border-red-500/40 active:scale-95 border border-white/10 flex items-center justify-center transition-all shadow-[0_4px_16px_rgba(0,0,0,0.5)] group"
            title="Google"
            aria-label="Sign in with Google"
          >
            {/* Google Colorful SVG Logo */}
            <svg className="w-5 h-5 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.27 21.43 7.34 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.27 2.57 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* Bottom Switch Link: "ليس لديك حساب؟ إنشاء حساب جديد" */}
      <div className="w-full shrink-0 text-center py-1 z-10">
        <p className="text-xs text-white/60">
          {isSignUp ? (
            <>
              {lang === "ar" ? "لديك حساب بالفعل؟ " : "Already have an account? "}
              <button
                type="button"
                onClick={() => setIsSignUp(false)}
                className="text-red-500 font-semibold hover:underline"
              >
                {lang === "ar" ? "تسجيل الدخول" : "Sign In"}
              </button>
            </>
          ) : (
            <>
              {lang === "ar" ? "ليس لديك حساب؟ " : "Don't have an account? "}
              <button
                type="button"
                onClick={() => setIsSignUp(true)}
                className="text-red-500 font-semibold hover:underline"
              >
                {lang === "ar" ? "إنشاء حساب جديد" : "Sign Up"}
              </button>
            </>
          )}
        </p>
      </div>
    </div>
  );
};
