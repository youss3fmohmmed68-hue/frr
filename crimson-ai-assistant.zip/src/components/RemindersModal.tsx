import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Bell, Plus, CheckCircle2, Circle, Trash2, Clock } from "lucide-react";
import { AIReminder } from "../types";
import { loadUserReminders, saveUserReminders } from "../utils/userStorage";

interface RemindersModalProps {
  isOpen: boolean;
  onClose: () => void;
  userKey?: string;
}

export const RemindersModal: React.FC<RemindersModalProps> = ({ isOpen, onClose, userKey = "guest" }) => {
  const [reminders, setReminders] = useState<AIReminder[]>(() => loadUserReminders(userKey));
  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("");

  // Reload when user changes
  useEffect(() => {
    setReminders(loadUserReminders(userKey));
  }, [userKey]);

  // Persist on change
  useEffect(() => {
    saveUserReminders(userKey, reminders);
  }, [userKey, reminders]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const item: AIReminder = {
      id: "rem-" + Date.now(),
      title: newTitle.trim(),
      time: newTime.trim() || "Today",
      completed: false,
    };
    setReminders([item, ...reminders]);
    setNewTitle("");
    setNewTime("");
  };

  const toggleComplete = (id: string) => {
    setReminders(
      reminders.map((r) => (r.id === id ? { ...r, completed: !r.completed } : r))
    );
  };

  const handleDelete = (id: string) => {
    setReminders(reminders.filter((r) => r.id !== id));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md rounded-3xl bg-neutral-950 border border-red-900/40 p-6 text-white shadow-2xl z-10 overflow-hidden flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-red-600/20 text-red-400">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-white">Reminders</h3>
                  <p className="text-xs text-white/50">Smart notifications & tasks</p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-1.5 rounded-full text-white/60 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Add Form */}
            <form onSubmit={handleAdd} className="my-3 space-y-2 shrink-0">
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="New reminder task..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-white/40 focus:outline-none focus:border-red-500"
                />
                <input
                  type="text"
                  placeholder="Time (e.g. 5:00 PM)"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="w-28 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-white/40 focus:outline-none focus:border-red-500"
                />
                <button
                  type="submit"
                  className="p-2 rounded-xl bg-red-600 hover:bg-red-500 text-white flex items-center justify-center transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </form>

            {/* Reminders List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 pt-1">
              {reminders.map((item) => (
                <div
                  key={item.id}
                  onClick={() => toggleComplete(item.id)}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                    item.completed
                      ? "bg-white/[0.01] border-white/5 opacity-50 line-through"
                      : "bg-white/[0.03] border-white/10 hover:border-red-500/30"
                  }`}
                >
                  <div className="flex items-center space-x-3 truncate">
                    {item.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-white/40 shrink-0" />
                    )}
                    <div className="truncate">
                      <p className="text-xs text-white truncate font-medium">{item.title}</p>
                      <div className="flex items-center space-x-1 text-[10px] text-red-300/80">
                        <Clock className="w-3 h-3" />
                        <span>{item.time}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(item.id);
                    }}
                    className="p-1 text-white/40 hover:text-red-400 rounded-md transition-colors shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
