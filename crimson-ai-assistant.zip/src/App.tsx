/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { RubyOrb } from "./components/RubyOrb";
import { Header } from "./components/Header";
import { ChatInput } from "./components/ChatInput";
import { ChatView } from "./components/ChatView";
import { SidebarDrawer } from "./components/SidebarDrawer";
import { UserProfileModal } from "./components/UserProfileModal";
import { PremiumModal } from "./components/PremiumModal";
import { DocumentsModal } from "./components/DocumentsModal";
import { RemindersModal } from "./components/RemindersModal";
import { HistoryModal } from "./components/HistoryModal";
import { HelpModal } from "./components/HelpModal";
import { VoiceOverlay } from "./components/VoiceOverlay";
import { AuthView } from "./components/AuthView";
import { SettingsView } from "./components/SettingsView";
import { ChatMessage, ChatSession, OrbState, UserProfile, MenuView } from "./types";
import { playPcmAudio, speakWithBrowser, stopBrowserSpeech } from "./utils/audio";
import { Sparkles, MessageSquare, Crown, ShieldAlert } from "lucide-react";
import { auth, signOut, onAuthStateChanged } from "./lib/firebase";
import {
  getUserStorageKey,
  loadUserSessions,
  saveUserSessions,
  loadUserProfile,
  saveUserProfile,
  DEFAULT_USER_PROFILE,
} from "./utils/userStorage";

export default function App() {
  // Active User Email / Storage Key initialization
  const initialIsAuth = () => {
    const saved = localStorage.getItem("crimson_is_authenticated");
    return saved ? JSON.parse(saved) : false;
  };

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(initialIsAuth);

  const initialUserEmail = () => localStorage.getItem("crimson_active_user_email") || "";
  const initialUserKey = getUserStorageKey(initialUserEmail());

  // User Profile
  const [user, setUser] = useState<UserProfile>(() => {
    return loadUserProfile(initialUserKey);
  });

  // Chat Sessions (isolated strictly per active user)
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    return loadUserSessions(initialUserKey);
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [orbState, setOrbState] = useState<OrbState>("idle");
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  // Active Menu View
  const [activeView, setActiveView] = useState<MenuView>("home");

  // UI Modals & Views
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isPremiumOpen, setIsPremiumOpen] = useState(false);
  const [isDocumentsOpen, setIsDocumentsOpen] = useState(false);
  const [isRemindersOpen, setIsRemindersOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isVoiceOverlayOpen, setIsVoiceOverlayOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // Speech Recognition state
  const [transcript, setTranscript] = useState("");
  const [voiceAssistantResponse, setVoiceAssistantResponse] = useState("");
  const recognitionRef = useRef<any>(null);

  // Active user storage key computed from current user email
  const currentUserKey = getUserStorageKey(user.email);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        const uKey = getUserStorageKey(firebaseUser.email || firebaseUser.uid);
        const loadedProfile = loadUserProfile(uKey, {
          name: firebaseUser.displayName || undefined,
          email: firebaseUser.email || undefined,
          avatarUrl:
            firebaseUser.photoURL ||
            `https://api.dicebear.com/7.x/bottts/svg?seed=${firebaseUser.uid}`,
        });
        const loadedSessions = loadUserSessions(uKey);

        setUser(loadedProfile);
        setSessions(loadedSessions);
        setMessages([]);
        setCurrentSessionId("");
        setIsAuthenticated(true);
        localStorage.setItem("crimson_is_authenticated", "true");
        localStorage.setItem("crimson_active_user_email", firebaseUser.email || firebaseUser.uid || "");
      }
    });
    return () => unsubscribe();
  }, []);

  // Persist user profile for the specific active user
  useEffect(() => {
    if (user.email) {
      saveUserProfile(currentUserKey, user);
    }
  }, [user, currentUserKey]);

  // Persist sessions strictly for the specific active user
  useEffect(() => {
    if (user.email) {
      saveUserSessions(currentUserKey, sessions);
    }
  }, [sessions, currentUserKey, user.email]);

  // Sync current session messages
  useEffect(() => {
    if (currentSessionId) {
      const active = sessions.find((s) => s.id === currentSessionId);
      if (active) {
        setMessages(active.messages);
      }
    } else {
      setMessages([]);
    }
  }, [currentSessionId, sessions]);

  // Handle Speech Recognition Init
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = user.preferredLanguage === "ar" ? "ar-SA" : "en-US";

      recognition.onstart = () => {
        setIsListening(true);
        setOrbState("listening");
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };

      recognition.onend = () => {
        setIsListening(false);
        if (transcript.trim()) {
          handleSendMessage(transcript.trim());
          setTranscript("");
        } else {
          setOrbState("idle");
        }
      };

      recognition.onerror = (err: any) => {
        console.warn("Speech recognition error:", err);
        setIsListening(false);
        setOrbState("idle");
      };

      recognitionRef.current = recognition;
    }
  }, [user.preferredLanguage, transcript]);

  // Start or Stop Voice Input
  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      setOrbState("idle");
    } else {
      stopBrowserSpeech();
      try {
        if (recognitionRef.current) {
          recognitionRef.current.lang = user.preferredLanguage === "ar" ? "ar-SA" : "en-US";
          recognitionRef.current.start();
        } else {
          setIsVoiceOverlayOpen(true);
        }
      } catch (e) {
        console.warn("Error starting speech recognition:", e);
      }
    }
  };

  // Open full Voice Overlay
  const startImmersiveVoiceMode = () => {
    setIsVoiceOverlayOpen(true);
    toggleListening();
  };

  // Send Message to Gemini AI
  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: ChatMessage = {
      id: "user-" + Date.now(),
      role: "user",
      content: text,
      timestamp: Date.now(),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setActiveView("home");
    setOrbState("thinking");

    // Create session if none active
    let activeId = currentSessionId;
    if (!activeId) {
      activeId = "session-" + Date.now();
      const newSession: ChatSession = {
        id: activeId,
        title: text.slice(0, 30) + (text.length > 30 ? "..." : ""),
        messages: newMessages,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setSessions((prev) => [newSession, ...prev]);
      setCurrentSessionId(activeId);
    } else {
      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeId
            ? { ...s, messages: newMessages, updatedAt: Date.now() }
            : s
        )
      );
    }

    try {
      let personalityGuide = "Be helpful, articulate, and well-structured.";
      if (user.personality === "concise") personalityGuide = "Be extremely concise, direct, and avoid filler.";
      if (user.personality === "creative") personalityGuide = "Be evocative, vivid, creative, and engaging.";
      if (user.personality === "code") personalityGuide = "Focus on clean, optimal code, syntax, and precise technical analysis.";

      const systemInstruction = `You are Crimson, an ultra-smart, responsive AI assistant with an aesthetic red aura.
The user's name is ${user.name}.
${personalityGuide}
Always format responses with clear markdown, bullet points, or code blocks when relevant.
If the query is in Arabic, respond in fluent high-quality Arabic. If in English, respond in natural English.`;

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          userName: user.name,
          systemInstruction,
        }),
      });

      const data = await res.json();
      const aiReply = data.text || data.fallback || "I am here to help!";

      const aiMessage: ChatMessage = {
        id: "model-" + Date.now(),
        role: "model",
        content: aiReply,
        timestamp: Date.now(),
      };

      const updatedMessages = [...newMessages, aiMessage];
      setMessages(updatedMessages);
      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeId
            ? { ...s, messages: updatedMessages, updatedAt: Date.now() }
            : s
        )
      );

      setVoiceAssistantResponse(aiReply);

      // Voice Playback if enabled
      if (user.autoSpeak || isVoiceOverlayOpen) {
        handleSpeakText(aiReply, aiMessage.id);
      } else {
        setOrbState("idle");
      }
    } catch (error) {
      console.error("Chat error:", error);
      const errorMessage: ChatMessage = {
        id: "err-" + Date.now(),
        role: "model",
        content: "I ran into a connection issue. Please make sure your Gemini API key is configured or try again in a moment.",
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
      setOrbState("idle");
    }
  };

  // Speak AI response via Gemini TTS or Browser Web Speech API fallback
  const handleSpeakText = async (text: string, messageId?: string) => {
    stopBrowserSpeech();
    if (messageId) setSpeakingMessageId(messageId);
    setOrbState("speaking");

    const cleanText = text.replace(/[*#`_~\[\]()]/g, "").slice(0, 450);

    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: cleanText,
          voiceName: user.voiceName || "Kore",
        }),
      });

      const data = await res.json();
      if (data.audio && data.format === "pcm") {
        await playPcmAudio(data.audio, data.sampleRate || 24000);
      } else {
        const langCode = user.preferredLanguage === "ar" ? "ar-SA" : "en-US";
        await speakWithBrowser(cleanText, langCode);
      }
    } catch (err) {
      const langCode = user.preferredLanguage === "ar" ? "ar-SA" : "en-US";
      await speakWithBrowser(cleanText, langCode);
    } finally {
      setSpeakingMessageId(null);
      setOrbState("idle");
    }
  };

  // Reset to clean Home Hero screen
  const handleStartNewChat = () => {
    setCurrentSessionId("");
    setMessages([]);
    setActiveView("home");
    setOrbState("idle");
    stopBrowserSpeech();
  };

  // Delete chat session
  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (currentSessionId === id) {
      handleStartNewChat();
    }
  };

  // Menu navigation router
  const handleSelectView = (view: MenuView) => {
    setActiveView(view);
    if (view === "home") {
      // Return to main screen
    } else if (view === "chats" || view === "history") {
      setIsHistoryOpen(true);
    } else if (view === "documents") {
      setIsDocumentsOpen(true);
    } else if (view === "reminders") {
      setIsRemindersOpen(true);
    } else if (view === "settings") {
      setActiveView("settings");
    } else if (view === "help") {
      setIsHelpOpen(true);
    }
  };

  // Logout handler
  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.warn("Sign out error:", err);
    }
    setIsAuthenticated(false);
    setUser(DEFAULT_USER_PROFILE);
    setSessions([]);
    setMessages([]);
    setCurrentSessionId("");
    localStorage.setItem("crimson_is_authenticated", "false");
    localStorage.removeItem("crimson_active_user_email");
    setIsSidebarOpen(false);
    setActiveView("home");
  };

  const handleLoginSuccess = (userData: Partial<UserProfile>) => {
    const uKey = getUserStorageKey(userData.email);
    const loadedProfile = loadUserProfile(uKey, userData);
    const loadedSessions = loadUserSessions(uKey);

    setUser(loadedProfile);
    setSessions(loadedSessions);
    setMessages([]);
    setCurrentSessionId("");
    setIsAuthenticated(true);
    localStorage.setItem("crimson_is_authenticated", "true");
    localStorage.setItem("crimson_active_user_email", userData.email || "");
  };

  const isHeroView = messages.length === 0;

  return (
    <main
      id="app-root-container"
      className="relative w-full h-full h-[100dvh] max-h-screen bg-black text-white flex flex-col justify-between selection:bg-red-500 selection:text-white overflow-hidden font-sans"
      style={{
        background:
          "radial-gradient(ellipse at 50% 65%, rgba(180, 10, 30, 0.45) 0%, rgba(110, 0, 20, 0.3) 38%, rgba(20, 0, 5, 0.95) 72%, #000000 100%)",
      }}
    >
      {/* Top subtle glow effect */}
      <div
        className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full pointer-events-none opacity-25"
        style={{
          background: "radial-gradient(circle, rgba(220, 20, 60, 0.6) 0%, transparent 70%)",
          filter: "blur(60px)",
        }}
      />

      {/* Main Content Area - dynamically fills 100% of device screen height and width */}
      <div
        id="app-content-container"
        className="relative w-full max-w-md md:max-w-xl lg:max-w-2xl mx-auto h-full flex flex-col justify-between overflow-hidden"
      >
        {!isAuthenticated ? (
          /* EXACT LOGIN / AUTHENTICATION VIEW (Matches user image 1:1) */
          <AuthView
            preferredLanguage={user.preferredLanguage}
            onLanguageChange={(newLang) =>
              setUser((prev) => ({ ...prev, preferredLanguage: newLang }))
            }
            onLoginSuccess={handleLoginSuccess}
          />
        ) : activeView === "settings" ? (
          /* EXACT SETTINGS VIEW (Matches user image 1:1) */
          <SettingsView
            user={user}
            onBack={() => setActiveView("home")}
            onUpdateUser={(updated) => {
              setUser((prev) => ({ ...prev, ...updated }));
              saveUserProfile(currentUserKey, { ...user, ...updated });
            }}
            onLogout={handleLogout}
            onClearHistory={() => {
              setMessages([]);
              setSessions([]);
              setCurrentSessionId("");
              saveUserSessions(currentUserKey, []);
            }}
          />
        ) : (
          <>
            {/* 1. Top Header & Status Bar */}
            <Header
              user={user}
              onOpenSidebar={() => setIsSidebarOpen(true)}
              onOpenProfile={() => setActiveView("settings")}
              onNewChat={handleStartNewChat}
              hasMessages={messages.length > 0}
            />

            {/* 2. Middle Content Area */}
            <div className="flex-1 flex flex-col justify-center items-center w-full px-4 overflow-hidden z-10 my-auto">
              {isHeroView ? (
                /* EXACT HERO VIEW (Matching the User Image 1:1) */
                <motion.div
                  id="hero-view-container"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4 }}
                  className="flex flex-col items-center text-center space-y-4 sm:space-y-6 w-full max-w-sm my-auto select-none py-2 sm:py-4"
                >
                  {/* 3D Glossy Ruby Orb with Specular Highlight */}
                  <div className="relative my-1 sm:my-2 shrink-0">
                    <RubyOrb
                      state={orbState}
                      size="large"
                      onClick={startImmersiveVoiceMode}
                    />
                  </div>

                  {/* Subtitle: "Hello, Tanvir!" */}
                  <div className="space-y-1 shrink-0">
                    <motion.p
                      id="hero-greeting-subtitle"
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.15 }}
                      className="text-white/70 text-sm sm:text-base md:text-lg font-medium tracking-wide"
                    >
                      {user.preferredLanguage === "ar"
                        ? `مرحباً، ${user.name.split(" ")[0]}!`
                        : `Hello, ${user.name.split(" ")[0]}!`}
                    </motion.p>

                    {/* Big Headline: "How Can I Help You Today?" */}
                    <motion.h1
                      id="hero-greeting-title"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.25 }}
                      className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight leading-[1.2] px-2"
                    >
                      {user.preferredLanguage === "ar" ? (
                        <>
                          كيف يمكنني مساعدتك
                          <br />
                          اليوم؟
                        </>
                      ) : (
                        <>
                          How Can I Help
                          <br />
                          You Today?
                        </>
                      )}
                    </motion.h1>
                  </div>

                  {/* Quick suggestion prompt chips */}
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.35 }}
                    className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 pt-1 px-2 shrink-0"
                  >
                    {[
                      { en: "Brainstorm creative ideas", ar: "أفكار إبداعية جديدة" },
                      { en: "Write clean TypeScript", ar: "كتابة كود تايب سكريبت" },
                      { en: "Summarize a topic", ar: "تلخيص موضوع معقد" },
                    ].map((chip, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSendMessage(user.preferredLanguage === "ar" ? chip.ar : chip.en)}
                        className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-white/[0.04] hover:bg-red-950/50 border border-white/10 hover:border-red-500/30 text-[11px] sm:text-xs text-white/80 hover:text-white transition-all active:scale-95 shadow-sm"
                      >
                        {user.preferredLanguage === "ar" ? chip.ar : chip.en}
                      </button>
                    ))}
                  </motion.div>
                </motion.div>
              ) : (
                /* CONVERSATION VIEW */
                <div className="flex-1 w-full flex flex-col h-full overflow-hidden py-2">
                  {/* Compact Orb Indicator at top of chat */}
                  <div className="flex items-center justify-center py-2 shrink-0">
                    <RubyOrb
                      state={orbState}
                      size="compact"
                      onClick={startImmersiveVoiceMode}
                    />
                  </div>

                  {/* Message List */}
                  <ChatView
                    messages={messages}
                    isThinking={orbState === "thinking"}
                    onSpeakText={handleSpeakText}
                    speakingMessageId={speakingMessageId}
                  />
                </div>
              )}
            </div>

            {/* 3. Floating Bottom Pill Input Bar (Matching Image 1:1) */}
            <div className="w-full pb-3 sm:pb-5 pt-1 sm:pt-2 z-20">
              <ChatInput
                onSendMessage={handleSendMessage}
                onStartVoice={toggleListening}
                isListening={isListening}
                placeholder={user.preferredLanguage === "ar" ? "اسأل أي شيء..." : "Ask anything..."}
                disabled={orbState === "thinking"}
              />
            </div>
          </>
        )}
      </div>

      {/* Navigation Sidebar Drawer (Matches new opened menu screenshot 1:1) */}
      <SidebarDrawer
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        user={user}
        activeView={activeView}
        onSelectView={handleSelectView}
        onOpenProfile={() => {
          setActiveView("settings");
          setIsSidebarOpen(false);
        }}
        onOpenPremium={() => setIsPremiumOpen(true)}
        onLogout={handleLogout}
      />

      {/* Interactive Feature Modals */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={user}
        onSave={(updated) => setUser((prev) => ({ ...prev, ...updated }))}
      />

      <PremiumModal
        isOpen={isPremiumOpen}
        onClose={() => setIsPremiumOpen(false)}
        isPremium={user.isPremium}
        onUpgrade={() => {
          setUser((prev) => ({ ...prev, isPremium: true }));
          alert("🎉 Welcome to Crimson AI Premium!");
        }}
      />

      <DocumentsModal
        isOpen={isDocumentsOpen}
        onClose={() => setIsDocumentsOpen(false)}
        onAskAboutDoc={(content) => handleSendMessage(content)}
        userKey={currentUserKey}
      />

      <RemindersModal
        isOpen={isRemindersOpen}
        onClose={() => setIsRemindersOpen(false)}
        userKey={currentUserKey}
      />

      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        sessions={sessions}
        onSelectSession={(id) => {
          setCurrentSessionId(id);
          setActiveView("home");
        }}
        onDeleteSession={handleDeleteSession}
        onClearAll={() => {
          setSessions([]);
          handleStartNewChat();
        }}
      />

      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
      />

      {/* Full Immersive Voice Mode Overlay */}
      <VoiceOverlay
        isOpen={isVoiceOverlayOpen}
        onClose={() => {
          setIsVoiceOverlayOpen(false);
          setIsListening(false);
          setOrbState("idle");
          stopBrowserSpeech();
        }}
        orbState={orbState}
        transcript={transcript}
        assistantResponse={voiceAssistantResponse}
        isListening={isListening}
        onToggleMic={toggleListening}
        userName={user.name}
      />
    </main>
  );
}
