export interface ChatMessage {
  id: string;
  role: "user" | "model";
  content: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

export type OrbState = "idle" | "listening" | "thinking" | "speaking";

export interface UserProfile {
  name: string;
  email: string;
  avatarUrl: string;
  preferredLanguage: "en" | "ar";
  autoSpeak: boolean;
  voiceName: "Kore" | "Puck" | "Zephyr" | "Fenrir" | "Charon";
  personality: "balanced" | "concise" | "creative" | "code";
  isPremium?: boolean;
}

export type MenuView =
  | "home"
  | "chats"
  | "history"
  | "documents"
  | "reminders"
  | "settings"
  | "help"
  | "premium";

export interface AIDocument {
  id: string;
  title: string;
  content: string;
  date: string;
  size: string;
}

export interface AIReminder {
  id: string;
  title: string;
  time: string;
  completed: boolean;
}

export interface QuickPrompt {
  id: string;
  labelEn: string;
  labelAr: string;
  promptEn: string;
  promptAr: string;
  icon: string;
}
