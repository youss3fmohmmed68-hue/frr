import { ChatSession, UserProfile, AIReminder, AIDocument } from "../types";

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: "Tanvir Ahmed",
  email: "tanvir@example.com",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  preferredLanguage: "en",
  autoSpeak: true,
  voiceName: "Kore",
  personality: "balanced",
  isPremium: false,
};

export function getUserStorageKey(email?: string, uid?: string): string {
  if (email && email.trim()) {
    return "user_" + email.trim().toLowerCase().replace(/[^a-z0-9]/g, "_");
  }
  if (uid && uid.trim()) {
    return "uid_" + uid.trim().replace(/[^a-z0-9]/g, "_");
  }
  return "guest_user";
}

export function loadUserSessions(userKey: string): ChatSession[] {
  try {
    const raw = localStorage.getItem(`crimson_sessions_${userKey}`);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn("Failed to parse user sessions:", err);
  }
  return [];
}

export function saveUserSessions(userKey: string, sessions: ChatSession[]): void {
  try {
    localStorage.setItem(`crimson_sessions_${userKey}`, JSON.stringify(sessions));
  } catch (err) {
    console.warn("Failed to save user sessions:", err);
  }
}

export function loadUserProfile(userKey: string, fallback?: Partial<UserProfile>): UserProfile {
  try {
    const raw = localStorage.getItem(`crimson_profile_${userKey}`);
    if (raw) {
      return { ...DEFAULT_USER_PROFILE, ...fallback, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.warn("Failed to parse user profile:", err);
  }
  return { ...DEFAULT_USER_PROFILE, ...fallback };
}

export function saveUserProfile(userKey: string, profile: UserProfile): void {
  try {
    localStorage.setItem(`crimson_profile_${userKey}`, JSON.stringify(profile));
  } catch (err) {
    console.warn("Failed to save user profile:", err);
  }
}

export function loadUserReminders(userKey: string): AIReminder[] {
  try {
    const raw = localStorage.getItem(`crimson_reminders_${userKey}`);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return [
    {
      id: "rem-1",
      title: "Review Project Architecture with Crimson AI",
      time: "Today at 3:00 PM",
      completed: false,
    },
    {
      id: "rem-2",
      title: "Prepare discussion points",
      time: "Tomorrow at 10:00 AM",
      completed: false,
    },
  ];
}

export function saveUserReminders(userKey: string, reminders: AIReminder[]): void {
  try {
    localStorage.setItem(`crimson_reminders_${userKey}`, JSON.stringify(reminders));
  } catch (e) {}
}

export function loadUserDocs(userKey: string): AIDocument[] {
  try {
    const raw = localStorage.getItem(`crimson_docs_${userKey}`);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return [
    {
      id: "doc-1",
      title: "AI Product Architecture & Roadmap.md",
      content: "# Crimson AI Architecture\n\n- Real-time Web Speech & Gemini TTS Integration\n- Low latency token streaming\n- Modern Ruby Orb Shader Aesthetics",
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      size: "2.4 KB",
    },
  ];
}

export function saveUserDocs(userKey: string, docs: AIDocument[]): void {
  try {
    localStorage.setItem(`crimson_docs_${userKey}`, JSON.stringify(docs));
  } catch (e) {}
}
